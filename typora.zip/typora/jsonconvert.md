```
`val events = sc.parallelize(   """{"action":"create","timestamp":1452121277}""" ::   """{"action":"create","timestamp":"1452121277"}""" ::   """{"action":"create","timestamp":""}""" ::   """{"action":"create","timestamp":null}""" ::   """{"action":"create","timestamp":"null"}""" ::   Nil )  val schema = (new StructType).add("action", StringType).add("timestamp", LongType)  sqlContext.read.schema(schema).json(events).show `
```

https://blog.antlypls.com/blog/2016/01/30/processing-json-data-with-sparksql/