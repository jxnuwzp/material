https://phoenixnap.com/kb/install-hive-on-ubuntu



https://www.edureka.co/blog/apache-hive-installation-on-ubuntu

