./kafka-topics.sh --create --zookeeper 10.128.164.42:2181,10.128.164.43:2181 --replication-factor 1 --partitions 3 --topic WilliamJOB

bin/kafka-console-producer.sh --broker-list 10.128.164.42:9092,10.128.164.43:9092 --topic WilliamJOB

./kafka-console-consumer.sh --bootstrap-server 10.128.164.42:9092,10.128.164.43:9092 --property print.key=true --topic WilliamVC --from-beginning


./kafka-topics.sh --delete --zookeeper 10.128.164.42:2181,10.128.164.43:2181 --topic WilliamJOB

bin/kafka-topics.sh --create --zookeeper localhost:2181 --replication-factor 1 --partitions 3 --topic WilliamJOB

./kafka-console-consumer.sh --bootstrap-server localhost:9092 --property print.key=true --topic williamonetopic --from-beginning

./kafka-topics.sh --alter --zookeeper 10.128.164.42:2181,10.128.164.43:2181 --topic EROutput --partitions 60
./kafka-topics.sh --describe  --zookeeper 10.128.164.37:2181,10.128.164.38:2181 --topic EROutput



echo 'VC,{"VC": "VCvalue","age": 22,"liability": 44.22}' | ./kafka-console-producer.sh \
              --broker-list 10.128.164.42:9092,10.128.164.43:9092 \
              --topic WilliamVC \
              --property parse.key=true \
              --property key.separator=,

echo 'JOB,{"JobId": 1234}' | ./kafka-console-producer.sh \
              --broker-list 10.128.164.42:9092,10.128.164.43:9092 \
              --topic WilliamJOB \
              --property parse.key=true \
              --property key.separator=,


echo '00000,{"name":"Steve", "title":"Captain America"}' | kafka-console-producer.sh \
              --broker-list localhost:9092 \
              --topic earth \
              --property parse.key=true \
              --property key.separator=,

scp retirementstudio-spark-be-1.0-SNAPSHOT-jar-with-dependencies.jar william@10.128.164.39://home/william/parallel

spark-submit --master yarn-cluster \
--jars /usr/hdp/current/hive_warehouse_connector/hive-warehouse-connector-assembly-1.0.0.3.1.5.0-152.jar \
--class erOutput.OneTopicMain retirementstudio-spark-be-1.0-SNAPSHOT-jar-with-dependencies.jar 



spark-submit --master yarn-client\
--jars /usr/hdp/current/hive_warehouse_connector/hive-warehouse-connector-assembly-1.0.0.3.1.5.0-152.jar \
--class erOutput.OneTopicMain retirementstudio-spark-be-1.0-SNAPSHOT-jar-with-dependencies.jar 