1,find file: / is for the path, whole directory will be searched.

```
find / -type f -name 'williampath'
```

2, find folder

```
find */* -xdev 2>/dev/null -name "williampath"
```

3,find process using special port

```
netstat -anop|grep 10000
```

4,hdfs search:

hdfs dfs -ls -R /user/gmanche/data/

hadoop fs -ls -R /user/rshive

hdfs dfs -text /user/rshive/output_demo/part-00000.deflate 



get database column info

SELECT  c.TABLE_SCHEMA ,
        c.TABLE_NAME ,
        c.COLUMN_NAME ,
        c.DATA_TYPE ,
        c.CHARACTER_MAXIMUM_LENGTH ,
        c.COLUMN_DEFAULT ,
        c.IS_NULLABLE ,
        c.NUMERIC_PRECISION ,
        c.NUMERIC_SCALE
FROM    [INFORMATION_SCHEMA].[COLUMNS] c
WHERE   TABLE_NAME = 'AggValuationEmployeeCR'

valocity

volume

varlely

veracity



5, mkdir

hadoop fs -mkdir hivedata