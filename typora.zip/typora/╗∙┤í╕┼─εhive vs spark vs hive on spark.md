**hive**

1. hive与hadoop关系：hive是基于Hadoop的一个数据仓库工具，Hive是建立在 Hadoop 上的数据仓库基础构架。 
2. 通俗意义上的hive，就是hive on mr

<img src="https://pic1.zhimg.com/v2-ff0e08e807f686b1d0b8d283197aa343_b.jpg" data-caption="" data-size="normal" data-rawwidth="1736" data-rawheight="894" class="origin_image zh-lightbox-thumb" width="1736" data-original="https://pic1.zhimg.com/v2-ff0e08e807f686b1d0b8d283197aa343_r.jpg"/>

Step 1：UI(user interface) 调用 executeQuery 接口，发送 HQL 查询语句给 Driver 

Step 2：Driver 为查询语句创建会话句柄，并将查询语句发送给 Compiler， 等待其进行语句解析并生成执行计划 

Step 3 and 4：Compiler 从 metastore 获取相关的元数据 

Step 5：元数据用于对查询树中的表达式进行类型检查，以及基于查询谓词调整分区，生成计划 

Step 6 (6.1，6.2，6.3)：由 Compiler 生成的执行计划是阶段性的 DAG，每个阶段都可能会涉及到 Map/Reduce job、元数据的操作、HDFS 文件的操作，Execution Engine 将各个阶段的 DAG 提交给对应的组件执行。 

Step 7, 8 and 9：在每个任务（mapper / reducer）中，查询结果会以临时文件的方式存储在 HDFS 中。保存查询结果的临时文件由 Execution Engine 直接从 HDFS 读取，作为从 Driver Fetch API 的返回内容。 

**spark-sql**

两个组件：SQLContext，DataFrame

1. SQLContext：Spark SQL提供SQLContext封装Spark中的所有关系型功能。可以用之前的示例中的现有SparkContext创建SQLContext。
2. DataFrame：DataFrame是一个分布式的，按照命名列的形式组织的数据集合。通过调用将DataFrame的内容作为行RDD（RDD of Rows）返回的rdd方法，可以将DataFrame转换成RDD。可以通过如下数据源创建DataFrame：已有的RDD、结构化数据文件、JSON数据集、Hive表、外部数据库。

<img src="https://pic1.zhimg.com/v2-20098b00d20ed2c17a40b18e61e83a45_b.jpg" data-caption="" data-size="normal" data-rawwidth="1842" data-rawheight="1128" class="origin_image zh-lightbox-thumb" width="1842" data-original="https://pic1.zhimg.com/v2-20098b00d20ed2c17a40b18e61e83a45_r.jpg"/>

**hive on spark**

hive on spark大体与SparkSQL结构类似，只是SQL引擎不同，但是计算引擎都是spark！

```text
#初始化Spark SQL
#导入Spark SQL
from pyspark.sql import HiveContext,Row
# 当不能引入Hive依赖时
# from pyspark.sql import SQLContext,Row
# 注意，上面那一点才是关键的，他两来自于同一个包，区别能有多大


hiveCtx = HiveContext(sc)   #创建SQL上下文环境
input = hiveCtx.jsonFile(inputFile)   #基本查询示例
input.registerTempTable("tweets")   #注册输入的SchemaRDD（SchemaRDD在Spark 1.3版本后已经改为DataFrame）
#依据retweetCount(转发计数)选出推文
topTweets = hiveCtx.sql("SELECT text,retweetCount FROM tweets ORDER BY retweetCount LIMIT 10")
```

sqlcontext和hivecontext都是出自于pyspark.sql包，可以从这里理解的话，其实hive on spark和sparksql并没有太大差别