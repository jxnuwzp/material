### 文章目录

- [一. Hive Cli的内部组成](https://blog.csdn.net/wwyzxb/article/details/87925688#_Hive_Cli_14)
- - [1.1. Diver](https://blog.csdn.net/wwyzxb/article/details/87925688#11_Diver_16)
  - - [1. 查询编译器（Query Compiler）](https://blog.csdn.net/wwyzxb/article/details/87925688#1_Query_Compiler_19)
    - [2. 任务执行计划](https://blog.csdn.net/wwyzxb/article/details/87925688#2__64)
  - [1.2. MetaStore](https://blog.csdn.net/wwyzxb/article/details/87925688#12_MetaStore_68)
  - - [1. 存储hive的元数据信息](https://blog.csdn.net/wwyzxb/article/details/87925688#1_hive_69)
    - [2. MetaStore Mode](https://blog.csdn.net/wwyzxb/article/details/87925688#2_MetaStore_Mode_87)
- [参考资料](https://blog.csdn.net/wwyzxb/article/details/87925688#_90)


以下内容是结合小象学院的hive视频整理的学习笔记
![在这里插入图片描述](https://img-blog.csdnimg.cn/2019022520285938.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d3eXp4Yg==,size_16,color_FFFFFF,t_70)
各个组件：
\1. Hive CLI：查询处理器
\2. MetaStore：元数据信息
\3. YARN：计算平台
\4. HDFS：数据存储
注：很多第三方组件一般只需要获得hive metaStore信息以及HDFS上的数据之后，就可以自己进行计算。



处理流程：

1. 根据MetaStore中的信息，将sql解析成MR任务，在提交给yarn去执行；
2. 处理后的结果存放在hdfs上，结果再返回给hive cli，解析好之后返回给用户。

# 一. Hive Cli的内部组成

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190225203608671.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d3eXp4Yg==,size_16,color_FFFFFF,t_70)

## 1.1. Diver

Hive的整个查询过程如下所示：
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190225205320171.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d3eXp4Yg==,size_16,color_FFFFFF,t_70)

### 1. 查询编译器（Query Compiler）

- 语法解析器（Syntax Parser）
  Hive中的语法解析是通过Antlr完成的（我们项目中有使用到Antlr4，后续空了一篇博客记录一下），可以将sql语句解析成AST-Tree，如下图所示（来自美团的一篇技术博客）：
  ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190225211900948.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d3eXp4Yg==,size_16,color_FFFFFF,t_70)
  我们继续以视频ppt中的案例为例：
  ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190225212300669.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d3eXp4Yg==,size_16,color_FFFFFF,t_70)
  TOK_WHERE节点可以继续解析成如下子树：
  ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190225212318967.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d3eXp4Yg==,size_16,color_FFFFFF,t_70)
- 语义分析器（Semantic Analyzer）
  AST Tree仍然非常复杂，不够结构化，不方便直接翻译为MapReduce程序，AST Tree通过语义分析之后转化为QueryBlock就是将SQL进一部抽象和结构化。

AST Tree生成QueryBlock的过程是一个递归的过程，先序遍历AST Tree，遇到不同的Token节点，保存到相应的属性中，主要包含以下几个过程：
(1) TOK_QUERY => 创建QB对象，循环递归子节点
(2) TOK_FROM => 将表名语法部分保存到QB对象的aliasToTabs等属性中
(3) TOK_INSERT => 循环递归子节点
(4) TOK_DESTINATION => 将输出目标的语法部分保存在QBParseInfo对象的nameToDest属性中
(5) TOK_SELECT => 分别将查询表达式的语法部分保存在destToSelExpr、destToAggregationExprs、destToDistinctFuncExprs三个属性中
(6) TOK_WHERE => 将Where部分的语法保存在QBParseInfo对象的destToWhereExpr属性中。

如下图所示的就是对于TOK_FROM转换成QB后的结果：

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190225212922229.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d3eXp4Yg==,size_16,color_FFFFFF,t_70)

- 生成逻辑计划（Logical Plan Gen）
  Hive最终生成的MapReduce任务，Map阶段和Reduce阶段均由OperatorTree组成。逻辑操作符，就是在Map阶段或者Reduce阶段完成单一特定的操作。

基本的操作符如下所示：
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190225215015183.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d3eXp4Yg==,size_16,color_FFFFFF,t_70)
通过QueryBlock可以生成Operator Tree就是遍历上一个过程中生成的QB和QBParseInfo对象的保存语法的属性，包含如下几个步骤：
(1) QB#aliasToSubq => 有子查询，递归调用
(2) QB#aliasToTabs => TableScanOperator
(3) QBParseInfo#joinExpr => QBJoinTree => ReduceSinkOperator + JoinOperator
(4) QBParseInfo#destToWhereExpr => FilterOperator
(5) QBParseInfo#destToGroupby => ReduceSinkOperator + GroupByOperator
(6) QBParseInfo#destToOrderby => ReduceSinkOperator + ExtractOperator

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190225214437614.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d3eXp4Yg==,size_16,color_FFFFFF,t_70)

- 优化逻辑计划（Logical Optinizer）
  大部分逻辑层优化器通过变换Operator Tree，合并操作符，达到减少MapReduce Job，减少shuffle数据量的目的。
  ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190225215459304.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d3eXp4Yg==,size_16,color_FFFFFF,t_70)
- 生成物理计划（Physical Plan Gen）
  在生成相应的查询计划之后，hive需要将逻辑计划转换成一个物理查询计划，这里是将其转换成MapReduce作业。
  ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190227195251967.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d3eXp4Yg==,size_16,color_FFFFFF,t_70)
- 物理任务优化（Physical Optimizer）
  根据sql语句的不同，map和reduce中包含的操作符也各不相同，但是某些操作符可以进行压缩，合并成一个操作符。接着则启动相应的MapTask和ReduceTask。
  ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190227195532178.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d3eXp4Yg==,size_16,color_FFFFFF,t_70)

### 2. 任务执行计划

- 执行物理计划
  由driver的Query Compiler对查询sql进行编译并生成相应的查询计划以及物理计划，最后再由执行引擎来执行物理计划。
  ![在这里插入图片描述](https://img-blog.csdnimg.cn/2019022720000684.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d3eXp4Yg==,size_16,color_FFFFFF,t_70)

## 1.2. MetaStore

### 1. 存储hive的元数据信息

- 库、表的基本信息
- 分区信息
- 列信息
- 存储格式信息
- 各种属性信息
- 权限信息

存储这些信息的具体表如下所示：
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190227200549749.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d3eXp4Yg==,size_16,color_FFFFFF,t_70)
通过show create table 命令我们可以查看hive表的元数据信息，如下所示：

```shell
0: jdbc:hive2://emr-header-1:2181,emr-header-> show create table default.events2;
1
```

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190227200827779.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d3eXp4Yg==,size_16,color_FFFFFF,t_70)
以上的这些信息都可以提供给driver，从而driver可以利用这些信息生成相应的查询计划。

### 2. MetaStore Mode

主要有三种模式：
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190227200933453.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3d3eXp4Yg==,size_16,color_FFFFFF,t_70)

# 参考资料

> [1] 美团技术 – Hive SQL的编译过程 https://tech.meituan.com/hive-sql-to-mapreduce.html