# Apache Spark Fine Grain Security with LLAP Test Drive

<https://community.hortonworks.com/articles/72454/apache-spark-fine-grain-security-with-llap-test-dr.html>



# ***hive integratation***

<https://docs.hortonworks.com/HDPDocuments/HDP3/HDP-3.0.1/integrating-hive/hive_integrating_hive_and_bi.pdf>



# ACID and Transactions in Hive

<https://cwiki.apache.org/confluence/display/Hive/Hive+Transactions>

<https://github.com/hortonworks/data-tutorials/blob/master/tutorials/hdp/using-hive-acid-transactions-to-insert-update-and-delete-data/tutorial.md#hello-acid-create-a-partitioned-acid-table-and-insert-some-data>



<https://github.com/hortonworks/data-tutorials/blob/master/tutorials/hdp/using-hive-acid-transactions-to-insert-update-and-delete-data/tutorial.md>



<https://community.hortonworks.com/articles/72454/apache-spark-fine-grain-security-with-llap-test-dr.html>



scala parallel(Futures and Promises)

https://twitter.github.io/scala_school/zh_cn/finagle.html#futsequential

https://stackoverflow.com/questions/19681389/use-case-of-scala-concurrent-blocking

https://monix.io/docs/2x/best-practices/blocking.html

https://docs.scala-lang.org/overviews/core/futures.html

https://www.jianshu.com/p/f858d31877c3

https://docs.scala-lang.org/zh-cn/overviews/core/futures.html

https://colobu.com/2015/06/11/Scala-Future-and-Promise/

https://code.csdn.net/DOC_Scala/chinese_scala_offical_document/file/Futures-and-Promises-cn.md

https://docs.scala-lang.org/overviews/core/futures.html

https://wiki.jikexueyuan.com/project/guides-to-scala-book/chp9-promises-and-futures-in-practice.html

[https://www.yangbajing.me/2015/11/28/scala%E5%AE%9E%E6%88%98%EF%BC%9A%E5%B9%B6%E5%8F%91-future%E5%92%8Cpromise/](https://www.yangbajing.me/2015/11/28/scala实战：并发-future和promise/)

