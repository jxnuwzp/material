https://blog.csdn.net/qq_36743482/article/details/78383964

https://blog.csdn.net/qq_36743482/article/details/78393678

https://github.com/jxnuwzp/spark-scala-kafka-consumer/blob/master/project/plugins.sbt

https://github.com/fedexist/KafkaHiveConnector/blob/master/build.sbt

<https://www.stubbornjava.com/posts/typesafe-config-features-and-example-usage>

