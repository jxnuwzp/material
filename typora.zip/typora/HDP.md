

## HDP:**

<https://docs.hortonworks.com/HDPDocuments/HDP3/HDP-3.0.1/integrating-hive/hive_integrating_hive_and_bi.pdf>



# **sparkStreamingKafkaPerformance**

https://github.com/jxnuwzp/sparkStreamingKafkaPerformance/blob/master/FunctionTestResult.md





| **IP Address** | **HostName**    | **Services**                             |
| -------------- | --------------- | ---------------------------------------- |
| 10.128.164.22  | mevnl-hdp6-yqr7 | -                                        |
| 10.128.164.33  | mevnl-hdp6-llfb | -       LLAP                             |
| 10.128.164.34  | mevnl-hdp6-etar | -Kafka Broker                            |
| 10.128.164.35  | mevnl-hdp6-5u5o | -        -       LLAP  -       Zookeeper |
| 10.128.164.36  | mevnl-hdp6-6x56 | -       Zookeeper  -       Kafka Broker  |

shanghai kafka

10.197.49.148:9092 

new one

| **IP Address**    | **HostName**        | **Services**                       |
| ----------------- | ------------------- | ---------------------------------- |
| **10.128.164.39** | **mevnl-hdp7-qqku** | -                                  |
| 10.128.164.40     | mevnl-hdp7-gegh     | -       LLAP                       |
| 10.128.164.41     | **mevnl-hdp7-nkc7** | -       LLAP                       |
| 10.128.164.42     | **mevnl-hdp7-ejmh** | -       HiveServer2  -       kafka |
| 10.128.164.43     | **mevnl-hdp7-5pbi** | -       kafka                      |

USE RSReport
GO
SELECT * FROM dbo.ERTableCode


SELECT TableCode,TableName FROM ERTableCode
UNION ALL
SELECT TableCode,TableName FROM dbo.JobbasedTables
UNION ALL
SELECT 'RD','RunDetail' 

select * From IndividualOutputField  where jobid=212679

select * From ValuationLiability where jobid=212684;