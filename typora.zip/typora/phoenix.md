1,

![image-20201009154357495](C:\Users\William-wang2\AppData\Roaming\Typora\typora-user-images\image-20201009154357495.png)

[erpostengine@mevnl-hdp6-5u5o ~]$ spark-shell --conf "spark.executor.extraClassPath=/usr/hdp/current/phoenix-client/phoenix-spark-5.0.0.3.1.5.0-152.jar:/usr/hdp/current/phoenix-client/phoenix-client.jar" --conf "spark.driver.extraClassPath=/usr/hdp/current/phoenix-client/phoenix-spark-5.0.0.3.1.5.0-152.jar:/usr/hdp/current/phoenix-client/phoenix-client.jar" 



2,

val df=spark.sqlContext.read.format("org.apache.phoenix.spark").option("table","DBO.VALUATIONBENEFITEXT1").option("zkUrl","mevnl-hdp6-6x56.azu.mrshmc.com,mevnl-hdp6-5u5o.azu.mrshmc.com:2181").load()



3,df.show

+------+-----------+--------------+---------+                                   
| JOBID|EMPLOYEEKEY|COMBINEDKEYEXT|ATTRVALUE|
+------+-----------+--------------+---------+
|190755|          1|      51511843|    0.000|
|190755|          1|      74187890| 1958.000|
|190755|          1|      74187954| 1494.000|
|190755|          1|      74188018| 1469.000|
|190755|          1|      74188082| 1015.000|
|190755|          1|      74450034|    0.000|
|190755|          1|      74450098|    0.000|
|190755|          1|      74450162|    0.000|
|190755|          1|      74450226|    0.000|
|190755|          2|      51511843|    0.000|
|190755|          2|      74187890| 1320.000|
|190755|          2|      74187954| 1688.000|
|190755|          2|      74188018| 1640.000|
|190755|          2|      74188082|  755.000|
|190755|          2|      74450034|    0.000|
|190755|          2|      74450098|    0.000|
|190755|          2|      74450162|    0.000|
|190755|          2|      74450226|    0.000|
|190755|          3|      51511843|    0.000|
|190755|          3|      74187890|12399.000|
+------+-----------+--------------+---------+



phoenix search:

1,

[erpostengine@mevnl-hdp6-5u5o bin]$ ./sqlline.py mevnl-hdp6-6x56.azu.mrshmc.com,mevnl-hdp6-5u5o.azu.mrshmc.com:2181

2,

0: jdbc:phoenix:mevnl-hdp6-6x56.azu.mrshmc.co> !tables
+------------+--------------+-----------------------+---------------+----------+------------+----------------------------+-----------------+--------------+-----------------+---------------+----------------+

| TABLE_CAT | TABLE_SCHEM | TABLE_NAME | TABLE_TYPE | REMARKS | TYPE_NAME | SELF_REFERENCING_COL_NAME | REF_GENERATION | INDEX_STATE | IMMUTABLE_ROWS | SALT_BUCKETS | MULTI_TENANT |
| --------- | ----------- | ---------- | ---------- | ------- | --------- | ------------------------- | -------------- | ----------- | -------------- | ------------ | ------------ |
|           |             |            |            |         |           |                           |                |             |                |              |              |
+------------+--------------+-----------------------+---------------+----------+------------+----------------------------+-----------------+--------------+-----------------+---------------+----------------+
|      | SYSTEM | CATALOG | SYSTEM TABLE |      |      |      |      |      | false | null | false |
| ---- | ------ | ------- | ------------ | ---- | ---- | ---- | ---- | ---- | ----- | ---- | ----- |
|      |        |         |              |      |      |      |      |      |       |      |       |
|      | SYSTEM | FUNCTION | SYSTEM TABLE |      |      |      |      |      | false | null | false |
| ---- | ------ | -------- | ------------ | ---- | ---- | ---- | ---- | ---- | ----- | ---- | ----- |
|      |        |          |              |      |      |      |      |      |       |      |       |
|      | SYSTEM | LOG  | SYSTEM TABLE |      |      |      |      |      | true | 32   | false |
| ---- | ------ | ---- | ------------ | ---- | ---- | ---- | ---- | ---- | ---- | ---- | ----- |
|      |        |      |              |      |      |      |      |      |      |      |       |
|      | SYSTEM | SEQUENCE | SYSTEM TABLE |      |      |      |      |      | false | null | false |
| ---- | ------ | -------- | ------------ | ---- | ---- | ---- | ---- | ---- | ----- | ---- | ----- |
|      |        |          |              |      |      |      |      |      |       |      |       |
|      | SYSTEM | STATS | SYSTEM TABLE |      |      |      |      |      | false | null | false |
| ---- | ------ | ----- | ------------ | ---- | ---- | ---- | ---- | ---- | ----- | ---- | ----- |
|      |        |       |              |      |      |      |      |      |       |      |       |
|      | DBO  | VALUATIONBENEFITEXT1 | TABLE |      |      |      |      |      | false | null | false |
| ---- | ---- | -------------------- | ----- | ---- | ---- | ---- | ---- | ---- | ----- | ---- | ----- |
|      |      |                      |       |      |      |      |      |      |       |      |       |
+------------+--------------+-----------------------+---------------+----------+------------+----------------------------+-----------------+--------------+-----------------+---------------+----------------+

3,

0: jdbc:phoenix:mevnl-hdp6-6x56.azu.mrshmc.co> select * from DBO.VALUATIONBENEFITEXT1;
+---------+--------------+-----------------+------------+
|  JOBID  | EMPLOYEEKEY  | COMBINEDKEYEXT  | ATTRVALUE  |
+---------+--------------+-----------------+------------+
| 190755  | 1            | 51511843        | 0          |
| 190755  | 1            | 74187890        | 1958       |
| 190755  | 1            | 74187954        | 1494       |
| 190755  | 1            | 74188018        | 1469       |
| 190755  | 1            | 74188082        | 1015       |
| 190755  | 1            | 74450034        | 0          |
| 190755  | 1            | 74450098        | 0          |
| 190755  | 1            | 74450162        | 0          |
| 190755  | 1            | 74450226        | 0          |
| 190755  | 2            | 51511843        | 0          |
| 190755  | 2            | 74187890        | 1.32E+3    |
| 190755  | 2            | 74187954        | 1688       |
| 190755  | 2            | 74188018        | 1.64E+3    |
| 190755  | 2            | 74188082        | 755        |
| 190755  | 2            | 74450034        | 0          |
| 190755  | 2            | 74450098        | 0          |
| 190755  | 2            | 74450162        | 0          |
| 190755  | 2            | 74450226        | 0          |
| 190755  | 3            | 51511843        | 0          |
| 190755  | 3            | 74187890        | 12399      |
| 190755  | 3            | 74187954        | 11739      |
| 190755  | 3            | 74188018        | 11731      |
| 190755  | 3            | 74188082        | 11715      |
| 190755  | 3            | 74450034        | 0          |
| 190755  | 3            | 74450098        | 0          |
| 190755  | 3            | 74450162        | 0          |
| 190755  | 3            | 74450226        | 0          |
| 190755  | 4            | 51511843        | 0          |
| 190755  | 4            | 74187890        | 14794      |
| 190755  | 4            | 74187954        | 15313      |
| 190755  | 4            | 74188018        | 15313      |
| 190755  | 4            | 74188082        | 15313      |
| 190755  | 4            | 74450034        | 0          |
| 190755  | 4            | 74450098        | 0          |
| 190755  | 4            | 74450162        | 0          |
| 190755  | 4            | 74450226        | 0          |
| 190755  | 5            | 51511843        | 0          |
| 190755  | 5            | 74187890        | 527        |
| 190755  | 5            | 74187954        | 454        |
| 190755  | 5            | 74188018        | 441        |
| 190755  | 5            | 74188082        | 1.3E+2     |
| 190755  | 5            | 74450034        | 0          |
| 190755  | 5            | 74450098        | 0          |
| 190755  | 5            | 74450162        | 0          |
| 190755  | 5            | 74450226        | 0          |
| 190755  | 6            | 51511843        | 0          |
| 190755  | 6            | 74187890        | 5935       |
| 190755  | 6            | 74187954        | 5.55E+3    |
| 190755  | 6            | 74188018        | 5501       |
| 190755  | 6            | 74188082        | 5431       |
| 190755  | 6            | 74450034        | 0          |
| 190755  | 6            | 74450098        | 0          |
| 190755  | 6            | 74450162        | 0          |
| 190755  | 6            | 74450226        | 0          |
| 190755  | 7            | 74188082        | 4471       |
| 190755  | 25           | 51511843        | 0          |
| 190755  | 25           | 74187890        | 4028       |
| 190755  | 25           | 74187954        | 4918       |
| 190755  | 25           | 74188018        | 4838       |
| 190755  | 25           | 74450034        | 0          |
| 190755  | 25           | 74450098        | 0          |
| 190755  | 25           | 74450162        | 0          |
| 190755  | 25           | 74450226        | 0          |
| 190755  | 26           | 51511843        | 0          |
| 190755  | 26           | 74187890        | 815        |
| 190755  | 26           | 74187954        | 807        |
| 190755  | 26           | 74188018        | 7.8E+2     |
| 190755  | 26           | 74188082        | 255        |
| 190755  | 26           | 74450034        | 0          |
| 190755  | 26           | 74450098        | 0          |
| 190755  | 26           | 74450162        | 0          |
| 190755  | 26           | 74450226        | 0          |
| 190755  | 27           | 51511843        | 0          |
| 190755  | 27           | 74187890        | 5636       |
| 190755  | 27           | 74187954        | 5386       |
| 190755  | 27           | 74188018        | 5386       |
| 190755  | 27           | 74188082        | 5386       |
| 190755  | 27           | 74450034        | 0          |
| 190755  | 27           | 74450098        | 0          |
| 190755  | 27           | 74450162        | 0          |
| 190755  | 27           | 74450226        | 0          |
| 190755  | 28           | 51511843        | 0          |
| 190755  | 28           | 74187890        | 4461       |
| 190755  | 28           | 74187954        | 4096       |
| 190755  | 28           | 74188018        | 4096       |
| 190755  | 28           | 74188082        | 3017       |
| 190755  | 28           | 74450034        | 0          |
| 190755  | 28           | 74450098        | 0          |
| 190755  | 28           | 74450162        | 0          |
| 190755  | 28           | 74450226        | 0          |
| 190755  | 29           | 51511843        | 0          |
| 190755  | 29           | 74187890        | 12628      |
| 190755  | 29           | 74187954        | 12199      |
| 190755  | 29           | 74188018        | 12199      |
| 190755  | 29           | 74188082        | 11783      |
| 190755  | 29           | 74450034        | 0          |
| 190755  | 29           | 74450098        | 0          |
| 190755  | 29           | 74450162        | 0          |
| 190755  | 29           | 74450226        | 0          |
+---------+--------------+-----------------+------------+
|  JOBID  | EMPLOYEEKEY  | COMBINEDKEYEXT  | ATTRVALUE  |
+---------+--------------+-----------------+------------+
| 220258  | 179          | 37788           | 4687.795   |
| 220258  | 180          | 37788           | 356.126    |
+---------+--------------+-----------------+------------+

hbase scan

1,

![image-20201009154312814](C:\Users\William-wang2\AppData\Roaming\Typora\typora-user-images\image-20201009154312814.png)

[erpostengine@mevnl-hdp6-5u5o ~]$ cd /usr/hdp/current/
[erpostengine@mevnl-hdp6-5u5o current]$ ls
accumulo-client    druid-middlemanager      hadoop-hdfs-portmap             hadoop-yarn-resourcemanager  hive-server2-hive         oozie-server     spark2-historyserver   tez-client
accumulo-gc        druid-overlord           hadoop-hdfs-secondarynamenode   hadoop-yarn-timelinereader   hive_warehouse_connector  phoenix-client   spark2-thriftserver    zeppelin-server
accumulo-master    druid-router             hadoop-hdfs-zkfc                hadoop-yarn-timelineserver   hive-webhcat              phoenix-server   spark-atlas-connector  zookeeper-client
accumulo-monitor   hadoop-client            hadoop-httpfs                   hbase-client                 kafka-broker              pig-client       spark-client           zookeeper-server
accumulo-tablet    hadoop-hdfs-client       hadoop-mapreduce-client         hbase-master                 knox-server               ranger-admin     spark_llap
accumulo-tracer    hadoop-hdfs-datanode     hadoop-mapreduce-historyserver  hbase-regionserver           livy2-client              ranger-tagsync   spark-schema-registry
druid-broker       hadoop-hdfs-journalnode  hadoop-yarn-client              hive-client                  livy2-server              ranger-usersync  storm-client
druid-coordinator  hadoop-hdfs-namenode     hadoop-yarn-nodemanager         hive-metastore               livy-client               shc              storm-nimbus
druid-historical   hadoop-hdfs-nfs3         hadoop-yarn-registrydns         hive-server2                 oozie-client              spark2-client    storm-supervisor
[erpostengine@mevnl-hdp6-5u5o current]$ cd hbase-client  

2,

[erpostengine@mevnl-hdp6-5u5o bin]$ hbase shell

3,

hbase(main):001:0> list
TABLE                                                                                                                                                                                                         
ATLAS_ENTITY_AUDIT_EVENTS                                                                                                                                                                                     
Contacts                                                                                                                                                                                                      
DBO.VALUATIONBENEFITEXT1                                                                                                                                                                                      
SYSTEM.CATALOG                                                                                                                                                                                                
SYSTEM.FUNCTION                                                                                                                                                                                               
SYSTEM.LOG                                                                                                                                                                                                    
SYSTEM.MUTEX                                                                                                                                                                                                  
SYSTEM.SEQUENCE                                                                                                                                                                                               
SYSTEM.STATS                                                                                                                                                                                                  
ambarismoketest                                                                                                                                                                                               
atlas_janus                                                                                                                                                                                                   
emp                                                                                                                                                                                                           
emptest                                                                                                                                                                                                       
erOutput:DimBenefitType                                                                                                                                                                                       
erOutput:DimEmployeeKeyStaging                                                                                                                                                                                
erOutput:DimPlanDef                                                                                                                                                                                           
erOutput:DimProvisionName                                                                                                                                                                                     
erOutput:DimTrancheType                                                                                                                                                                                       
erOutput:Execution                                                                                                                                                                                            
erOutput:GLValuationBenefitExt                                                                                                                                                                                
erOutput:GLValuationBenefitExt1                                                                                                                                                                               
erOutput:JobParameter                                                                                                                                                                                         
erOutput:RunDetail                                                                                                                                                                                            
erOutput:RunDetailType                                                                                                                                                                                        
erOutput:test                                                                                                                                                                                                 
mytest                                                                                                                                                                                                        
26 row(s)
Took 0.4653 seconds                                                                                                                                                                                           
=> ["ATLAS_ENTITY_AUDIT_EVENTS", "Contacts", "DBO.VALUATIONBENEFITEXT1", "SYSTEM.CATALOG", "SYSTEM.FUNCTION", "SYSTEM.LOG", "SYSTEM.MUTEX", "SYSTEM.SEQUENCE", "SYSTEM.STATS", "ambarismoketest", "atlas_janus", "emp", "emptest", "erOutput:DimBenefitType", "erOutput:DimEmployeeKeyStaging", "erOutput:DimPlanDef", "erOutput:DimProvisionName", "erOutput:DimTrancheType", "erOutput:Execution", "erOutput:GLValuationBenefitExt", "erOutput:GLValuationBenefitExt1", "erOutput:JobParameter", "erOutput:RunDetail", "erOutput:RunDetailType", "erOutput:test", "mytest"]

4,

hbase(main):004:0> scan "erOutput:test";
hbase(main):005:0* scan "erOutput:test"
ROW                                                  COLUMN+CELL                                                                                                                                              
 \x80\x03\x5C`\x80\x00\x00\xB0\x80\x00\x93\x9C       column=fields:c1, timestamp=1600830915022, value=4687.79565                                                                                              
 \x80\x03\x5C`\x80\x00\x00\xB0\x80\x00\x93\x9C       column=fields:c2, timestamp=1600830915022, value=1997-03-10 00:00:00.000                                                                                 
 \x80\x03\x5C`\x80\x00\x00\xB0\x80\x00\x93\x9C       column=fields:c3, timestamp=1600830915022, value=True                                                                                                    
1 row(s)
Took 0.4286 seconds                                                                                                                                                                                           
ROW                                                  COLUMN+CELL                                                                                                                                              
 \x80\x03\x5C`\x80\x00\x00\xB0\x80\x00\x93\x9C       column=fields:c1, timestamp=1600830915022, value=4687.79565                                                                                              
 \x80\x03\x5C`\x80\x00\x00\xB0\x80\x00\x93\x9C       column=fields:c2, timestamp=1600830915022, value=1997-03-10 00:00:00.000                                                                                 
 \x80\x03\x5C`\x80\x00\x00\xB0\x80\x00\x93\x9C       column=fields:c3, timestamp=1600830915022, value=True                                                                                                    
1 row(s)
Took 0.0170 seconds                                                                                                                                                                                           
hbase(main):006:0> 

![image-20201009154202303](C:\Users\William-wang2\AppData\Roaming\Typora\typora-user-images\image-20201009154202303.png)



**deployment:**

spark-submit --master yarn-cluster \
--jars /usr/hdp/current/hive_warehouse_connector/hive-warehouse-connector-assembly-1.0.0.3.1.5.0-152.jar \
--conf spark.locality.wait.process=200ms \
--conf spark.locality.wait.node=10ms \
--conf "spark.executor.extraClassPath=/usr/hdp/current/phoenix-client/phoenix-spark-5.0.0.3.1.5.0-152.jar:/usr/hdp/current/phoenix-client/phoenix-client.jar" \
--conf "spark.driver.extraClassPath=/usr/hdp/current/phoenix-client/phoenix-spark-5.0.0.3.1.5.0-152.jar:/usr/hdp/current/phoenix-client/phoenix-client.jar" \
--num-executors=3 \
--executor-memory=3G \
--driver-memory=2G \
--class erOutput.Main.erOutputMain retirementstudio-spark-be-1.0-SNAPSHOT-jar-with-dependencies.jar 



reference:https://www.yuque.com/huangsheng7271/cczf84/zi1lvz