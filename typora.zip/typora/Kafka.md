# zookeeper  and Kafka install steps:



##### Download zookeeper  zookeeper-3.4.13.tar.gz from  http://zookeeper.apache.org/releases.html

before install zookeeper and kafka,you should install java

1, Extract tar file:

```
$ cd opt/
$ tar -zxvf zookeeper-3.4.6.tar.gz
$ cd zookeeper-3.4.6
$ mkdir data
```

2, use command vim "conf/zoo.cfg" configuration setting:

```
$ vim conf/zoo.cfg
dataDir=/path/to/zookeeper/data
```

3, start zookeeper server:

```
$ bin/zkServer.sh start
```

responseyes

```
$ JMX enabled by default
$ Using config: /Users/../zookeeper-3.4.6/bin/../conf/zoo.cfg
$ Starting zookeeper ... STARTED
```

4,start CLI

```
$ bin/zkCli.sh
```

response

```
Connecting to localhost:2181
................
................
................
Welcome to ZooKeeper!
................
................
WATCHER::
WatchedEvent state:SyncConnected type: None path:null
[zk: localhost:2181(CONNECTED) 0]
```

5,stop zookeeper server:

```
$ bin/zkServer.sh stop
```



##### Download kafka <https://www.apache.org/dyn/closer.cgi?path=/kafka/0.9.0.0/kafka_2.11-0.9.0.0.tgz>

1, Extract tar file:

```
$ cd opt/
$ tar -zxf kafka_2.11.0.9.0.0 tar.gz
$ cd kafka_2.11.0.9.0.0
```



2,start kafka server

```
$ bin/kafka-server-start.sh config/server.properties
```

response

```
$ bin/kafka-server-start.sh config/server.properties
[2016-01-02 15:37:30,410] INFO KafkaConfig values:
request.timeout.ms = 30000
log.roll.hours = 168
inter.broker.protocol.version = 0.9.0.X
log.preallocate = false
security.inter.broker.protocol = PLAINTEXT
…………………………………………….
…………………………………………….
```

3,stop kafka broker server

```
$ bin/kafka-server-stop.sh config/server.properties

kafka always running:
$ nohup bin/kafka-server-stop.sh config/server.properties 1>/dev/null 2>&1 &
```

4, after start kafka broker, type "jps" in the terminal, kafka and QuorumPeerMain processes will be shown

```
821 QuorumPeerMain
928 Kafka
931 Jps
```

5,create topic:

```
bin/kafka-topics.sh --create --zookeeper localhost:2181 --replication-factor 1   
--partitions 1 --topic Hello-Kafka
```

6,get topic list:

```
bin/kafka-topics.sh --list --zookeeper localhost:2181
```

7,start producer 

```
bin/kafka-console-producer.sh --broker-list localhost:9092 --topic Hello-Kafka
```

8,start consumer:

```
bin/kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic Hello-Kafka 
--from-beginning
```

```
bin/kafka-console-consumer.sh --bootstrap-server 10.128.164.34:9092,10.128.164.36:9092 --topic AggPayoutParticipantStaging --from-beginning
```

9,look at participants:

```
bin/kafka-topics.sh --describe --zookeeper localhost:2181-topic Hello-Kafka
```

10, delete topic

```
$ ./bin/kafka-topics.sh --zookeeper localhost:2181 --delete --topic remove-me
```

## Windows running Kafka

1. Go to your Kafka installation directory: C:\kafka_2.11-0.9.0.0\

2. Open a command prompt here by pressing *Shift + right click* and choose the “Open command window here” option).

3. Now type `.\bin\windows\kafka-server-start.bat .\config\server.properties` and press Enter.

   ```
   .\bin\windows\kafka-server-start.bat .\config\server.properties
   ```

4,create topic:

```
.\bin\windows\kafka-topics.bat --create --zookeeper localhost:2181 --replication-factor 1 --partitions 1 --topic test
```

5,list topic:

```
.\bin\windows\kafka-topics.bat --list --zookeeper localhost:2181
```

6,producer:

```
.\bin\windows\kafka-console-producer.bat --broker-list localhost:9092 --topic test
```

7,consumer:

```
.\bin\windows\kafka-console-consumer.bat --bootstrap-server localhost:9092 --topic test --from-beginning
```

8,kafka数据倾斜

http://ningg.top/apache-kafka-10-best-practice-tips-data-skew-details/

## Install kafka as windows service**

(i) Use NSSM (a FREE service manager) and enter the below in Path and Arguments, to create a Windows service for ZooKeeper:
 Path:     `<ZooKeeper directory>\bin\windows\zookeeper-server-start.bat` 
 Arguments: `<ZooKeeper directory>\config\zookeeper.properties` 

(ii) Use NSSM (a FREE service manager) and enter the below in Path and Arguments, to create a Windows service for Kafka:
 Path:     `<Kafka directory>\bin\windows\kafka-server-start.bat` 
 Arguments: `<Kafka directory>\config\kafka.properties`

Provide a dependency of ZooKeeper service (under the Dependencies tab in the NSSM setup of Kafka), so that when you startup Kafka service, ZooKeeper service is automatically started (if it isn't running already).

https://zooesblog.wordpress.com/2016/03/15/installing-apache-zookeeper-and-kafka-as-windows-service/



## source code 

https://github.com/lukemerrett/Kafka-Windows-Service/tree/master/KafkaService



## **some useful introduce about partition,segment and offset:**

<https://www.cnblogs.com/yitianyouyitian/p/10287293.html>

[https://leibnizhu.gitlab.io/2017/12/22/Spark2%E7%9A%84Kafka%20Offset%E7%AE%A1%E7%90%86/](https://leibnizhu.gitlab.io/2017/12/22/Spark2的Kafka Offset管理/)

<https://my.oschina.net/u/816457/blog/1632670>

## Some Other Useful Commands

1. List Topics: `kafka-topics.bat --list --zookeeper localhost:2181`  
2. Describe Topic: `kafka-topics.bat --describe --zookeeper localhost:2181 --topic [Topic Name]`
3. Read messages from the beginning: `kafka-console-consumer.bat --bootstrap-server localhost:9092 --topic [Topic Name] --from-beginning`
4. Delete Topic: `kafka-run-class.bat kafka.admin.TopicCommand --delete --topic [topic_to_delete] --zookeeper localhost:2181`



Summay:

1,zookeeper manage kafka metadata(offset,topic)



kafka cluster:

<https://www.jianshu.com/p/475d02c76ba7>

Kafka message format:

ConsumerRecord(topic = EROutput, partition = 0, offset = 45214, CreateTime = 1561959902227, serialized key size = 23, serialized value size = 237, headers = RecordHeaders(headers = [], isReadOnly = false), key = ValuationBenefitPBGCmax, value = {"jobid":205019,"valuationbenefitpbgckey":147,"employeekey":148,"executionid":343256,"prioritycategory":3,"accruedliabilitypbgc4044":0.0,"employeeidnumber":"382020148","status":"Retired","liabilitytype":"PBGC_Plan_Term","datacenter":"0"})





performance:

https://www.cloudera.com/documentation/enterprise/latest/topics/kafka_performance_large_messages.html

kafka parameters:

https://blog.csdn.net/isea533/article/details/73720066

kafka studying:

https://kafka.apache.org/quickstart