## sbt installation

1,download sbt sbt-0.13.17.tgz from http://www.scala-sbt.org/download.html

2,sudo tar zxvf sbt-0.13.5.tgz -C /usr/local/

3,create launch sbt script:

```
SBT_OPTS="-Xms512M -Xmx1536M -Xss1M -XX:+CMSClassUnloadingEnabled -XX:MaxPermSize=256M"
java $SBT_OPTS -jar /usr/local/sbt/bin/sbt-launch.jar "$@" 
```

4,authorize sbt script file execuite permission

```
$ chmod u+x sbt 
```

5, set path environment:

```
$ vim ~/.bashrc
export PATH=/usr/local/sbt/:$PATH

/*make it works*/
$ source ~/.bashrc
```

6,test whether sbt install successfully:

```
mercer@williamlocal:~$ sbt "show sbtVersion"
Java HotSpot(TM) 64-Bit Server VM warning: ignoring option MaxPermSize=256M; support was removed in 8.0
[info] Loading global plugins from /home/mercer/.sbt/1.0/plugins
[info] Loading project definition from /home/mercer/project
[info] Set current project to mercer (in build file:/home/mercer/)
[info] 1.2.1
```

7,reference:

<https://www.cnblogs.com/wrencai/p/3867898.html>

8,compare maven with sbt:

https://blog.csdn.net/cjuexuan/article/details/51148002



package:

## 1,go to code folder:

```
cd ~/IdeaProjects/retirementstudio-spark
```



## 2,execuite sbt clean,sbt compile,sbt package

```
ercer@williamlocal:~/IdeaProjects/retirementstudio-spark$ sbt clean
Java HotSpot(TM) 64-Bit Server VM warning: ignoring option MaxPermSize=256M; support was removed in 8.0
[info] Loading global plugins from /home/mercer/.sbt/1.0/plugins
[info] Updating ProjectRef(uri("file:/home/mercer/.sbt/1.0/plugins/"), "global-plugins")...
[info] Done updating.
[info] Loading project definition from /home/mercer/IdeaProjects/retirementstudio-spark/project
[info] Updating ProjectRef(uri("file:/home/mercer/IdeaProjects/retirementstudio-spark/project/"), "retirementstudio-spark-build")...
[info] Done updating.
[info] Loading settings for project retirementstudio-spark from build.sbt ...
[info] Set current project to retirementstudio-spark (in build file:/home/mercer/IdeaProjects/retirementstudio-spark/)
[success] Total time: 0 s, completed May 10, 2019 1:11:47 AM


mercer@williamlocal:~/IdeaProjects/retirementstudio-spark$ sbt compile
Java HotSpot(TM) 64-Bit Server VM warning: ignoring option MaxPermSize=256M; support was removed in 8.0
[info] Loading global plugins from /home/mercer/.sbt/1.0/plugins
[info] Loading project definition from /home/mercer/IdeaProjects/retirementstudio-spark/project
[info] Loading settings for project retirementstudio-spark from build.sbt ...
[info] Set current project to retirementstudio-spark (in build file:/home/mercer/IdeaProjects/retirementstudio-spark/)
[info] Executing in batch mode. For better performance use sbt's shell
[info] Updating ...
[info] Done updating.
[warn] There may be incompatibilities among your library dependencies; run 'evicted' to see detailed eviction warnings.
[info] Compiling 1 Scala source to /home/mercer/IdeaProjects/retirementstudio-spark/target/scala-2.11/classes ...
[info] Done compiling.
[success] Total time: 52 s, completed May 10, 2019 1:12:54 AM


mercer@williamlocal:~/IdeaProjects/retirementstudio-spark$ sbt package
Java HotSpot(TM) 64-Bit Server VM warning: ignoring option MaxPermSize=256M; support was removed in 8.0
[info] Loading global plugins from /home/mercer/.sbt/1.0/plugins
[info] Loading project definition from /home/mercer/IdeaProjects/retirementstudio-spark/project
[info] Loading settings for project retirementstudio-spark from build.sbt ...
[info] Set current project to retirementstudio-spark (in build file:/home/mercer/IdeaProjects/retirementstudio-spark/)
[info] Packaging /home/mercer/IdeaProjects/retirementstudio-spark/target/scala-2.11/retirementstudio-spark_2.11-0.1.jar ...
[info] Done packaging.
[success] Total time: 9 s, completed May 10, 2019 1:13:23 AM
```

## 3, the .jar file generated

![1557476785791](C:\Users\William-wang2\AppData\Roaming\Typora\typora-user-images\1557476785791.png)