**
1．Hive安装及配置**

 **（1）解压安装包到安装目录。**

　　![img](https://img2018.cnblogs.com/blog/1198130/201909/1198130-20190904191018320-1082747397.png)

 

 

 **（2）修改apache-hive-1.2.1-bin.tar.gz的名称为hive。**

　　**![img](https://img2018.cnblogs.com/blog/1198130/201909/1198130-20190904191145636-1215950396.png)**

 

 

 **（3）修改/opt/module/hive/conf目录下的hive-env.sh.template名称为hive-env.sh：$ mv hive-env.sh.template hive-env.sh**

 **（4）配置hive-env.sh文件**

　　**（a）配置HADOOP_HOME路径**

　　　　**export HADOOP_HOME=/opt/module/hadoop-2.7.2**

　　**（b）配置HIVE_CONF_DIR路径**

　　　　**export HIVE_CONF_DIR=/opt/module/hive/conf**

**2．Hadoop集群配置**

**（1）必须启动hdfs和yarn**  

　　**$ sbin/start-dfs.sh**

　　**$ sbin/start-yarn.sh**

**（2）在HDFS上创建/tmp和/user/hive/warehouse两个目录并修改他们的同组权限可写**

　　**$ bin/hadoop fs -mkdir /tmp**

　　**$ bin/hadoop fs -mkdir -p /user/hive/warehouse**

　　**$ bin/hadoop fs -chmod g+w /tmp**

　　**$ bin/hadoop fs -chmod g+w /user/hive/warehouse**

**3．Hive基本操作**

**（1）启动hive**

　　**$ bin/hive**

**（2）查看数据库**

　　**hive> show databases;**

**![img](https://img2018.cnblogs.com/blog/1198130/201909/1198130-20190904191803272-769814689.png)**

**（3）打开默认数据库**

　　**hive> use default;**

**![img](https://img2018.cnblogs.com/blog/1198130/201909/1198130-20190904191834388-986959176.png)**

**（4）显示default数据库中的表**

　　**hive> show tables;**

**（5）创建一张表**

　　**hive> create table student(id int, name string);**

**![img](https://img2018.cnblogs.com/blog/1198130/201909/1198130-20190904191932179-491482655.png)**

**（6）显示数据库中有几张表**

　　**hive> show tables;**

**![img](https://img2018.cnblogs.com/blog/1198130/201909/1198130-20190904192009379-1429565947.png)**

**（7）查看表的结构**

　　**hive> desc student;**

**![img](https://img2018.cnblogs.com/blog/1198130/201909/1198130-20190904192033848-1911171211.png)**

**（8）向表中插入数据**

　　**hive> insert into student values(1000,"ss");**

**![img](https://img2018.cnblogs.com/blog/1198130/201909/1198130-20190904192124349-91510303.png)**

**（9）查询表中数据**

　　**hive> select \* from student;**

**![img](https://img2018.cnblogs.com/blog/1198130/201909/1198130-20190904192202751-1335725037.png)**

**（10）退出hive**

　　**hive> quit;**