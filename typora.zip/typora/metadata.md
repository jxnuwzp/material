scp AggregationRegistryProcedure.txt william@10.128.164.39://home/william/metadata
scp DimPayoutBenefitType.txt  william@10.128.164.39://home/william/metadata           
scp ReportingNumDataFormat.txt  william@10.128.164.39://home/william/metadata
scp AggregationRegistryResultType.txt  william@10.128.164.39://home/william/metadata 
scp DimStatus.txt  william@10.128.164.39://home/william/metadata                      
scp ResultCategory.txt  william@10.128.164.39://home/william/metadata
scp DimDecrementAgeGroup.txt    william@10.128.164.39://home/william/metadata         
scp individualoutputstandardresult.txt   william@10.128.164.39://home/william/metadata
scp ResultFieldExt.txt  william@10.128.164.39://home/william/metadata
scp DimDecrementType.txt  william@10.128.164.39://home/william/metadata              
scp LiabilitySubType.txt  william@10.128.164.39://home/william/metadata
scp DimLiabilityType.txt   william@10.128.164.39://home/william/metadata             
scp RefLiabilityType.txt  william@10.128.164.39://home/william/metadata

hdfs dfs -put AggregationRegistryProcedure.txt /user/william/metadata
hdfs dfs -put DimPayoutBenefitType.txt /user/william/metadata
hdfs dfs -put ReportingNumDataFormat.txt /user/william/metadata
hdfs dfs -put DimStatus.txt /user/william/metadata
hdfs dfs -put ResultCategory.txt /user/william/metadata
hdfs dfs -put DimDecrementAgeGroup.txt /user/william/metadata
hdfs dfs -put individualoutputstandardresult.txt /user/william/metadata
hdfs dfs -put ResultFieldExt.txt /user/william/metadata
hdfs dfs -put DimDecrementType.txt /user/william/metadata
hdfs dfs -put LiabilitySubType.txt /user/william/metadata
hdfs dfs -put DimLiabilityType.txt /user/william/metadata
hdfs dfs -put RefLiabilityType.txt /user/william/metadata