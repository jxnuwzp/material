

现在我们Hive数据库中有4类表。

1. Inv开头的表，用来存原始数据了

2. Inter开头的表，是用存每一批Agg的数据

3. Agg开头的表，是jobComplete的时候最后把Inter的表最一个final的Agg

4. 元数据表，现在设计让Ethan通过Hive来存放的

你们就用小本子记着吧 :)