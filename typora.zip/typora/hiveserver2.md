## hiveserver2 configuration:

## 1,hive-site.xml  ,hive/conf/hive-site.xml

```
<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<?xml-stylesheet type="text/xsl" href="configuration.xsl"?>
<configuration>
<property>
    <name>hive.exec.scratchdir</name>
    <value>/home/mercer/Downloads/hadoop/tmp/hive/tmp</value>
</property>
<property>
    <name>hive.metastore.warehouse.dir</name>
    <value>/home/mercer/Downloads/hadoop/tmp/hive/warehouse</value>
</property>
<property>
    <name>hive.metastore.local</name>
    <value>/home/mercer/Downloads/hadoop/tmp/hive/warehouse</value>
</property>
<property>
  <name>javax.jdo.option.ConnectionURL</name>
  <value>jdbc:mysql://localhost/metastore?createDatabaseIfNotExist=true&amp;serverTimezone=UTC&amp;useUnicode=true&amp;characterEncoding=utf8&amp;useSSL=false</value>
<!--<value>jdbc:postgresql://localhost/metastore</value>-->
</property>
<property>
    <name>hive.metastore.uris</name>
    <value>thrift://localhost:9083</value>
   <description>Thrift URI for the remote metastore. Used by metastore client to connect to remote metastore.</description>
</property>

<property>
  <name>javax.jdo.option.ConnectionDriverName</name>
  <value>com.mysql.cj.jdbc.Driver</value>
<!--<value>org.postgresql.Driver</value>-->
</property>

<property>
  <name>javax.jdo.option.ConnectionUserName</name>
  <value>root</value>
</property>

<property>
  <name>javax.jdo.option.ConnectionPassword</name>
  <value></value>
</property>
<property>
  <name>datanucleus.autoCreateSchema</name>
  <value>true</value>
</property>

<property>
  <name>datanucleus.fixedDatastore</name>
  <value>true</value>
</property>

<property>
 <name>datanucleus.autoCreateTables</name>
 <value>True</value>
 </property>
 <property>
    <name>hive.exec.script.wrapper</name>
    <value/>
    <description/>
  </property>
<property>
    <name>hive.metastore.schema.verification</name>
    <value>false</value>
  </property>

<property>
   <name>hive.server2.thrift.port</name>
   <value>10000</value>
</property>
<property>
   <name>hive.server2.thrift.bind.host</name>
   <value>localhost</value>
</property>
<property>
    <name>hive.server2.authentication</name>
    <value>NONE</value>
</property>
<property>
	<name>hive.zookeeper.quorum</name>
	<value>localhost:2181</value>
	<description>
	</description>
</property>
<property>
	<name>hive.zookeeper.client.port</name>
	<value>2181</value>
	<description>
	</description>
</property>
<property>
	<name>hive.support.concurrency</name>
	<description>Enable Hive's Table Lock Manager Service</description>
	<value>true</value>
</property>
<property>
	<name>hive.server2.webui.host</name>
	<value>localhost</value>
	<description>The host address the HiveServer2 WebUI will listen on</description>
</property>
<property>
	<name>hive.server2.webui.port</name>
	<value>10002</value>
	<description>The port the HiveServer2 WebUI will listen on. This can beset to 0or a negative integer to disable the web UI</description>
</property>
</configuration> 
```

## 2, core-site.xml, hadoop/etc/hadoop/core-site.xml

```
<configuration>
 <property>
   <name>hadoop.native.lib</name>
   <value>false</value>
   <description>should native hadoop libraries,if present, be used.</description>
  </property>
  <property>
    <name>fs.default.name</name>
    <value>hdfs://localhost:9000</value>
  </property>

<property>     
	<name>hadoop.proxyuser.mercer.hosts</name>     
	<value>*</value> 
</property> 
<property>     
	<name>hadoop.proxyuser.mercer.groups</name>     
	<value>*</value> 
</property>
</configuration>
```

## test whether hiveserver2 is ok

**1,start zookeeper**,**Important:** Failure to do this will prevent HiveServer2 from handling concurrent query requests and may result in data corruption.Enabling the Table Lock Manager without specifying a list of valid Zookeeper quorum nodes will result in unpredictable behavior

```
mercer@williamlocal:~/Downloads/zookeeper$ bin/zkServer.sh start
```

**2,start metastore**

```
mercer@williamlocal:~$ hive --service metastore
```

**3,start hiveserver2**

```
mercer@williamlocal:~$ hive --service hiveserver2
```

or

```
mercer@williamlocal:~$ hiveserver2
```

**4, beeline to fonfirm hiveserver2 is working. the username and password are namenode's username and password.**

```
beeline> !connect jdbc:hive2://localhost:10000

Connecting to jdbc:hive2://localhost:10000
Enter username for jdbc:hive2://localhost:10000: mercer
Enter password for jdbc:hive2://localhost:10000: ******
Connected to: Apache Hive (version 2.3.2)
Driver: Hive JDBC (version 2.3.2)
Transaction isolation: TRANSACTION_REPEATABLE_READ
0: jdbc:hive2://localhost:10000> show databases;
+-------------------+
|   database_name   |
+-------------------+
| default           |
| sparktest         |
| valutionemployee  |
+-------------------+
3 rows selected (1.604 seconds)
0: jdbc:hive2://localhost:10000> 
```

<https://www.cloudera.com/documentation/enterprise/5-6-x/topics/cdh_ig_hiveserver2_start_stop.html>



the hive UI:

![1558503119782](C:\Users\William-wang2\AppData\Roaming\Typora\typora-user-images\1558503119782.png)