## jump server:

137.116.60.134 

william/Mercer@123



## ambari:

https://40.84.58.136/ambari/#/ 

 The new HDP cluster url: http://10.128.164.8:8080

 And your ambari user: 

william/mercerA123



hive log:ip 10.128.164.44

/var/hive/metastorelog

## new cluster：2019-11-12

10.128.164.6

10.128.164.23

10.128.164.24

10.128.164.25

10.128.164.26





old cluster:

![image-20201109104105481](C:\Users\William-wang2\AppData\Roaming\Typora\typora-user-images\image-20201109104105481.png)

 



Abmari URL: http://mevnl-jsha-os56.azu.mrshmc.com:8080



## spark-shell

spark-shell --jars /usr/hdp/current/hive_warehouse_connector/hive-warehouse-connector-assembly-1.0.0.3.1.5.0-152.jar

val hive = com.hortonworks.spark.sql.hive.llap.HiveWarehouseBuilder.session(spark).build()

hive.setDatabase("clouddb")

import spark.implicits._

import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

import org.apache.spark.rdd.RDD 



import spark.implicits._
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

 val jobId = 205846
 val lastJobId = 205842
 val currentJobId = jobId

val df = hive.executeQuery(s"select * from DimEmployeeKeyStaging where jobId=${currentJobId}")
df.createOrReplaceTempView("tvDimEmployeeKeyStaging")
df.show

 spark-shell复制和粘贴

先输入:paste，然后*粘贴*代码块，之后按ctrl+D结束输入

配置文件

设置自动删除delete all application logs from spark history

```
spark.history.fs.cleaner.enabled true
spark.history.fs.cleaner.maxAge  12h
spark.history.fs.cleaner.interval 1h
```

 