how to set the permission to hdfs

https://www.informit.com/articles/article.aspx?p=2755708&seqNum=3

https://blog.csdn.net/Evankaka/article/details/51612437

http://dblab.xmu.edu.cn/blog/install-hadoop/

https://www.cnblogs.com/lanxuezaipiao/p/3525554.html

https://note.qidong.name/2018/12/install-hadoop-2.8.5/

