1，数据类型

```
import org.apache.spark.mllib.linalg.{Matrix, Matrices}

// Create a dense matrix ((1.0, 2.0), (3.0, 4.0), (5.0, 6.0))
val dm: Matrix = Matrices.dense(3, 2, Array(1.0, 3.0, 5.0, 2.0, 4.0, 6.0))

// Create a sparse matrix ((9.0, 0.0), (0.0, 8.0), (0.0, 6.0))
val sm: Matrix = Matrices.sparse(3, 2, Array(0, 1, 3), Array(0, 2, 1), Array(9, 6, 8)
```

稠密是以列为优先，记录所有的值

稀疏是记录非零值

对于DenseMatrix的初始化参数不难理解，定义行数，列数以及所有元素值，（注，列式优先存储），然后并产生DenseMatrix矩阵；

而对于SparseMatrix的初始化参数有点难理解，并非是我们常见的三元组存储方式，可以先看看源码的定义：

![这里写图片描述](http://img.blog.csdn.net/20170105093547527?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvc2luYXRfMjk1MDgyMDE=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)

关于参数numRows（行数）,numCols（列数）,rowIndices（行向索引），values（元素值），这些好理解，难懂的是colPtrs参数，这里通过一图来解释这个参数意义所在。

![这里写图片描述](http://img.blog.csdn.net/20170105095732841?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvc2luYXRfMjk1MDgyMDE=/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/SouthEast)

这样就容易理解多了。

参考：https://www.cnblogs.com/zhangbojiangfeng/p/7456961.html

**创建标注**

```
scala> import org.apache.spark.mllib.linalg.Vectors import org.apache.spark.mllib.linalg.Vectors scala> import org.apache.spark.mllib.regression.LabeledPoint import org.apache.spark.mllib.regression.LabeledPoint //创建一个标签为1.0（分类中可视为正样本）的稠密向量标注点 scala> val pos = LabeledPoint(1.0, Vectors.dense(2.0, 0.0, 8.0)) pos: org.apache.spark.mllib.regression.LabeledPoint = (1.0,[2.0,0.0,8.0]) //创建一个标签为0.0（分类中可视为负样本）的稀疏向量标注点 scala> val neg = LabeledPoint(0.0, Vectors.sparse(3, Array(0, 2), Array(2.0, 8.0))) neg: org.apache.spark.mllib.regression.LabeledPoint = (0.0,(3,[0,2],[2.0,8.0]))
```

[平均数](https://baike.baidu.com/item/平均数)：

![img](https://bkimg.cdn.bcebos.com/formula/6e931edc086948c3b206e5d224d667ff.svg)

 （n表示这组数据个数，x1、x2、x3……xn表示这组数据具体数值）

[方差公式](https://baike.baidu.com/item/方差公式)：

![img](https://bkimg.cdn.bcebos.com/formula/8ddc32475dfe46aa38b43ddd37f5c85b.svg)

标准方差公式(1)：

![img](https://bkimg.cdn.bcebos.com/formula/cb374717fb90f8da6f5479a2f4efae6d.svg)

L0范数是指向量中非0的元素的个数。(L0范数很难优化求解)

L1范数是指向量中各个元素绝对值之和

L2范数是指向量各元素的平方和然后求平方根

L1范数可以进行特征选择，即让特征的系数变为0.

L2范数可以防止过拟合，提升模型的泛化能力，有助于处理 condition number不好下的矩阵(数据变化很小矩阵求解后结果变化很大)

（核心：L2对大数，对outlier离群点更敏感！）

下降速度：最小化权值参数L1比L2变化的快

模型空间的限制：L1会产生稀疏 L2不会。

L1会趋向于产生少量的特征，而其他的特征都是0，而L2会选择更多的特征，这些特征都会接近于0。

概念

范数是具有“长度”概念的函数。在向量空间内，为所有的向量的赋予非零的增长度或者大小。不同的范数，所求的向量的长度或者大小是不同的。

举个例子，2维空间中，向量(3,4)的长度是5，那么5就是这个向量的一个范数的值，更确切的说，是欧式范数或者L2范数的值。

![img](https://pic2.zhimg.com/80/v2-b1fc63fb060cb7ccf6d040bc7e675a95_hd.png)

 

特别的，L0范数：指向量中非零元素的个数。无穷范数：指向量中所有元素的最大绝对值。

————————————————
版权声明：本文为CSDN博主「rocling」的原创文章，遵循CC 4.0 BY-SA版权协议，转载请附上原文出处链接及本声明。
原文链接：https://blog.csdn.net/rocling/java/article/details/90290576