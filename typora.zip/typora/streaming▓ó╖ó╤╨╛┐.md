https://colobu.com/2015/01/05/kafka-spark-streaming-integration-summary/

https://stackoverflow.com/questions/31590592/spark-streaming-read-and-write-on-kafka-topic

https://www.cnblogs.com/xlturing/p/6246538.html

https://medium.com/@rinu.gour123/apache-kafka-spark-streaming-integration-af7bd87887fb

https://spark.apache.org/docs/2.3.2/streaming-kafka-0-8-integration.html