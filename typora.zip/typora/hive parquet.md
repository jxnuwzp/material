<https://sparkbyexamples.com/spark-read-parquet-example/>



