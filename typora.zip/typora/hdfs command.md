# [ HDFS Commands](http://hadoopguide.blogspot.com/2013/06/hadoop-ecosystem-hdfs-commands.html)      

In Hadoop's Distributed File System or any other file system in hadoop, you can perform various files/directory operations by following commands :

### FS Shell: 

- The FileSystem (FS) shell is invoked by        bin/hadoop fs <args>.
- All the FS shell commands take path URIs as arguments.
- The URI      format is *scheme://autority/path*.
- For HDFS the scheme      is *hdfs*, and for the local filesystem the scheme      is *file*.
- The scheme and authority are optional. If not      specified, the default scheme specified in the configuration is      used.
- An HDFS file or directory such as */parent/child*      can be specified as *hdfs://namenodehost/parent/child* or      simply as */parent/child* (given that your configuration      is set to point to *hdfs://namenodehost*).
-  Error information is sent to ***stderr*** and the      output is sent to **stdout**.


**Commands:**

cat

   Command: 

hadoop fs -cat URI [URI …]

   Example: 

hadoop fs -cat hdfs://nn1.example.com/file1 hdfs://nn2.example.com/file

​                   

*hadoop fs -cat file:///file3 /user/hadoop/file4*  

   Description: 

Returns 0 on success and -1 on error. 

Copies source paths to 

stdout

. 

chgrp



   Command: 

hadoop fs -chgrp [-R] GROUP URI [URI …]

   Example: 

hadoop fs -chgrp -R GROUP hdfs://nn1.example.com/file1

   Description: 

Change group association of files. With 

-R

, make the change recursively through the

​                         directory structure. The user must be the owner of files, or else a super-user.

chmod

   Command: 

hadoop fs -chmod [-R] <MODE[,MODE]... | OCTALMODE> URI [URI …]

   Example: 

hadoop fs -chmod -R 777 hdfs://nn1.example.com/file1

   Description:

 Change the permissions of files. With 

-R

, make the change recursively through the

​                        directory structure. The user must be the owner of the file, or else a super-user. 

chown



   Command: 

hadoop fs -chown [-R] [OWNER][:[GROUP]] URI [URI ]

   Example: 

   Description: 

Change the owner of files. With 

-R

, make the change recursively through the

​                         directory structure. The user must be a super-user.

copyFromLocal



   Command: 

hadoop fs -copyFromLocal <localsrc> URI

   Example: *hadoop fs -copyFromLocal /tmp/test.txt /opt/hadoop/test.txt*

   Description: 

Similar to 

**put**

 command, except that the source is restricted to a local file

​                         reference. 

copyToLocal



   Command: 

hadoop fs -copyToLocal [-ignorecrc] [-crc] URI <localdst>

   Example: *hadoop fs -copyToLocal /opt/hadoop/test.txt /tmp/test.txt*

   Description: 

Similar to 

**get**

 command, except that the destination is restricted to a local file

​                        reference.

cp



   Command: 

hadoop fs -cp URI [URI …] <dest>

   Example: 

hadoop fs -cp /user/hadoop/file1 /user/hadoop/file2 /user/hadoop/dir 

   Description: 

Returns 0 on success and -1 on error. 

Copy files from source to destination. This

​    command allows multiple  sources as well in which case the destination must be a directory.      

du

   Command: 

hadoop fs -du URI [URI …]

   Example: 

fs -du /user/hadoop/dir1 /user/hadoop/file1 hdfs://nn.example.com/user/hadoop/dir1

   Description: 

Returns 0 on success and -1 on error. 

Displays aggregate length of  files contained

​                         in the directory or the length of a file in case its just a file. 

dus 

   Command: 

hadoop fs -dus <args>

   Example: 

   Description: 

Displays a summary of file lengths.

expunge

   Command: 

hadoop fs -expunge

   Example: 

   Description: 

Empty the Trash. Refer to 

HDFS Design

 for more information on Trash feature. 

get 

   Command: 

hadoop fs -get [-ignorecrc] [-crc] <src> <localdst>

   Example: 

hadoop fs -get hdfs://nn.example.com/user/hadoop/file localfile

   Description: 

Returns 0 on success and -1 on error. 

Copy files to the local file system. Files that

​                         fail the CRC check may be copied with the       

-ignorecrc

 option. Files and CRCs may

​                         be copied using the 

-crc

 option.    

getmerge 



   Command: 

hadoop fs -getmerge <src> <localdst> [addnl]

   Example: 

   Description: 

Takes a source directory and a destination file as input and  concatenates files in src

​     into the destination local file. Optionally 

addnl

 can be set to enable adding a newline character

​     at the end of each file.      

ls

   Command: 

hadoop fs -ls <args>

   Example: 

hadoop fs -ls /user/hadoop/file1 /user/hadoop/file2 hdfs://nn.example.com 

​                   /user/hadoop/dir1 /nonexistentfile

   Description: 

Returns 0 on success and -1 on error.

 For a file returns stat on the file with the

​     following format: 

filename <number of replicas> filesize modification_date modification_time 

​    permissions userid groupid

​            For a directory it returns list of its direct children as in unix.          A

​    directory is listed as: 

dirname <dir> modification_time modification_time permissions userid 

​    groupid

lsr



   Command: 

hadoop fs -lsr <args>

   Example: 

   Description: 

Recursive version of 

ls

. Similar to Unix 

ls -R

.

mkdir



   Command: 

hadoop fs -mkdir <paths>



   Example: 

hadoop fs -mkdir hdfs://nn1.example.com/user/hadoop/dir hdfs://nn2.example.com

​                    /user/hadoop/dir    

   Description:

Takes path uri's as argument and creates directories. The behavior is  much like unix 

​                       mkdir -p creating parent directories along the path.    

movefromLocal



   Command: 

dfs -moveFromLocal <src> <dst>



   Example: 

   Description: 

Displays a "not implemented" message.     

mv



   Command: 

hadoop fs -mv URI [URI …] <dest>



   Example: 

hadoop fs -mv hdfs://nn.example.com/file1 hdfs://nn.example.com/file2 

​                    hdfs://nn.example.com/file3 hdfs://nn.example.com/dir1

   Description: 

Moves files from source to destination. This command allows multiple  sources as

​                         well in which case the destination needs to be a directory.  Moving files across

​                         filesystems is not permitted.      

put

  Command: 

hadoop fs -put <localsrc> ... <dst>



   Example: 

hadoop fs -put localfile hdfs://nn.example.com/hadoop/hadoopfile

   Description: 

Returns 0 on success and -1 on error. 

Copy single src, or multiple srcs from local

​     file system to the  destination filesystem. Also reads input from stdin and writes to  destination

​     filesystem.

rm

 

 Command: 

hadoop fs -rm URI [URI …] 

   Example: 

hadoop fs -rm hdfs://nn.example.com/file /user/hadoop/emptydir 

   Description: 

Returns 0 on success and -1 on error. 

Delete files specified as args. Only deletes

​     non empty directory and files. Refer to rmr for recursive deletes.

rmr

  Command: 

hadoop fs -rmr URI [URI …]

   Example: 

hadoop fs -rmr /user/hadoop/dir 

   Description: 

Returns 0 on success and -1 on error. 

Recursive version of delete.

setrep

  Command: 

hadoop fs -setrep [-R] <path>

   Example: 

hadoop fs -setrep -w 3 -R /user/hadoop/dir1 

   Description: 

Returns 0 on success and -1 on error. 

Changes the replication factor of a file. -R

​         option is for recursively  increasing the replication factor of files within a directory.    

stat

  Command: 

hadoop fs -stat URI [URI …]

   Example: 

hadoop fs -stat path 

   Description: 

Returns 0 on success and -1 on error. 

Returns the stat information on the path.

tail

  

Command: 

hadoop fs -tail [-f] URI 



   Example: 

hadoop fs -tail pathname 

   Description: 

Returns 0 on success and -1 on error. 

Displays last kilobyte of the file to stdout. -f

​                         option can be used as in Unix.     

test

  Command: 

hadoop fs -test -[ezd] URIhttp://www.blogger.com/blogger.g?blogID=2197476253361244570#editor/target=post;postID=1883036932755640654;onPublishedMenu=allposts;onClosedMenu=allposts;postNum=0;src=link

   Example: 

hadoop fs -test -e filename 

   Description: 

Options: 

​                         -e check to see if the file exists. Return 0 if true. 

​                         -z check to see if the file is zero length. Return 0 if true 

​                         -d check return 1 if the path is directory else return 0.

text

  

Command: 

hadoop fs -text <src>

   Example: 



   Description: 

Takes a source file and outputs the file in text format. The allowed formats are zip

​                         and TextRecordInputStream.    

touchz

  

Command: 

hadoop fs -touchz URI [URI …]

   Example: 

hadoop -touchz pathname 

   Description: 

Returns 0 on success and -1 on error. 

Create a file of zero length.     

​                                        Source:

 http://hadoop.apache.org/docs/r0.18.3/hdfs_shell.html

   

###  

reference:http://hadoopguide.blogspot.com/