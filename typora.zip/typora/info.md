

https://github.com/hortonworks-spark/spark-llap/blob/master/README.md

http://www.cnblogs.com/zlslch/p/6801898.html

https://blog.csdn.net/duyuanhai/article/details/74942449

https://blog.csdn.net/zlmm228/article/details/81063416

https://github.com/hortonworks-spark/spark-llap/blob/master/README.md









https://blog.csdn.net/qq_36743482/article/details/78393678

https://jaceklaskowski.gitbooks.io/mastering-spark-sql/spark-sql-DataFrameWriter.html

<https://blog.csdn.net/qq_36743482/article/details/78383964>

<https://www.cnblogs.com/EnzoDin/p/6951181.html>

<https://blog.csdn.net/zx_blog/article/details/79128429>

<https://blog.csdn.net/m0_37367424/article/details/82458705>

<https://blog.csdn.net/qq_36743482/article/details/78393678>

<https://www.yiibai.com/hive/hive_partitioning.html>