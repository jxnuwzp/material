add user for localhost/127.0.0.1

​    

```
#create user 'newuser'@'localhost' identified by 'password';
#flush privileges; 
```

https://blog.csdn.net/ljxfblog/article/details/80197277

