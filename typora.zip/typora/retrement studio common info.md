## **store procedure tuning:**

https://wiki.mercer.com/display/RSCS/Spark+Stored-proc+Tuning+Status

https://wiki.mercer.com/display/RSCS/Non-US+PostEngine+Stored+Procs



## **Retirement studio DEV**

DEV CURRENT Build:\\USDFW14WS52V\Stu Drop\



## search spark log:

yarn logs -applicationId application_1606195392894_0042>agg.txt

yarn logs -applicationId application_1607927586781_0012>streaming1010.txt





filter logManager words

cat streaming1010.txt |grep "logManager:" -n

查找：/error\c 其中\c是不计大小写

## SCP:

scp retirementstudio-spark-be-1.0-SNAPSHOT-jar-with-dependencies.jar william@10.128.164.38://home/william/code
scp retirementstudio-spark-be-1.0-SNAPSHOT-jar-with-dependencies.jar erpostengine@10.128.164.38://home/erpostengine/code



**retirement studio filter contidition:**

$emp.EmployeeIDNumber<=100688085





## Spark-submit

1,

spark-submit --master yarn-cluster \
--jars /usr/hdp/current/hive_warehouse_connector/hive-warehouse-connector-assembly-1.0.0.3.1.5.0-152.jar \
--class erOutput.Main.erOutputMain retirementstudio-spark-be-1.0-SNAPSHOT-jar-with-dependencies.jar

2.

spark-submit --master yarn-cluster \
--jars /usr/hdp/current/hive_warehouse_connector/hive-warehouse-connector-assembly-1.0.0.3.1.0.0-78.jar \
--class SaveHive.MetadataIntoHive retirementstudio-spark-be-1.0-SNAPSHOT-jar-with-dependencies.jar \
--num-executors 5 \
--executor-memory 8G \
--executor-cores 4

3,

spark-submit --master yarn-cluster \
--jars /usr/hdp/current/hive_warehouse_connector/hive-warehouse-connector-assembly-1.0.0.3.1.0.0-78.jar \
--class erOutput.testCacheMain retirementstudio-spark-be-1.0-SNAPSHOT-jar-with-dependencies.jar \
--num-executors 5 \
--executor-memory 8G \
--executor-cores 4



**new HDP 2020-07-29**

IP Address      HostName      Services

10.128.164.33  mevnl-hdp9-wo7x.azu.mrshmc.com     -       Hive LLAP

10.128.164.29  mevnl-hdp9-qo66.azu.mrshmc.com     -       Master

10.128.164.35  mevnl-hdp9-pnl4.azu.mrshmc.com      -       kafka

10.128.164.32  mevnl-hdp9-miwc.azu.mrshmc.com     -       master second, HiveServer2

10.128.164.34  mevnl-hdp9-fjhv.azu.mrshmc.com      -       LLAP, Kafka



Your username/password: william/mercer123**

URL: http://10.128.164.29:8080/, need to setup tunnel first.



**kafka**

./kafka-topics.sh --create \
--zookeeper 10.128.164.34:2181,10.128.164.35:2181 \
--replication-factor 1 \
--partitions 600 \
--topic EROutput

./kafka-topics.sh --create \
--zookeeper 10.128.164.34:2181,10.128.164.35:2181 \
--replication-factor 1 \
--partitions 1 \
--topic JobPersistCompleted

./kafka-topics.sh --create \
--zookeeper 10.128.164.34:2181,10.128.164.35:2181 \
--replication-factor 1 \
--partitions 1 \
--topic SparkAggFinishedEvent

./kafka-topics.sh --list --zookeeper 10.128.164.34:2181,10.128.164.35:2181
./kafka-topics.sh --describe  --zookeeper 10.128.164.34:2181,10.128.164.35:2181 --topic EROutput
./kafka-topics.sh --describe  --zookeeper 10.128.164.34:2181,10.128.164.35:2181 --topic JobPersistCompleted
./kafka-topics.sh --describe  --zookeeper 10.128.164.34:2181,10.128.164.35:2181 --topic SparkAggFinishedEvent





**kafka exactly once**

https://www.baeldung.com/kafka-exactly-once

https://cwiki.apache.org/confluence/display/KAFKA/KIP-98+-+Exactly+Once+Delivery+and+Transactional+Messaging

https://www.confluent.io/blog/exactly-once-semantics-are-possible-heres-how-apache-kafka-does-it/

[‎2020/‎8/‎3 11:07] Guo, Weili: 

**OnPremise of QA US Benchmark 013 Create New** 

**Cloud of QA US Benchmark 013 Create New** 

QA US Benchmark 013 Create New Plan>>FundingValuations>>2009 Plan>>Use Prescribed Rate 

 

[‎2020/‎8/‎3 11:12] Wang, William: 

好的

 

 