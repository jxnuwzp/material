![image-20200622135847532](C:\Users\William-wang2\AppData\Roaming\Typora\typora-user-images\image-20200622135847532.png)

1，job![image-20200622140311223](C:\Users\William-wang2\AppData\Roaming\Typora\typora-user-images\image-20200622140311223.png)

2，stage21

![image-20200622140538910](C:\Users\William-wang2\AppData\Roaming\Typora\typora-user-images\image-20200622140538910.png)

3，staging 20

![image-20200622140646086](C:\Users\William-wang2\AppData\Roaming\Typora\typora-user-images\image-20200622140646086.png)

![image-20200622140743932](C:\Users\William-wang2\AppData\Roaming\Typora\typora-user-images\image-20200622140743932.png)

**Scala**:

```scala
import org.apache.spark.sql.functions.broadcast

val smallDF: DataFrame = ???
val largeDF: DataFrame = ???

largeDF.join(broadcast(smallDF), Seq("foo"))
```

or broadcast hint (Spark >= 2.2):

```
largeDF.join(smallDF.hint("broadcast"), Seq("foo"))
```

**SQL**

You can use hints ([Spark >= 2.2](https://issues.apache.org/jira/browse/SPARK-16475)):

```sql
SELECT /*+ MAPJOIN(small) */ * 
FROM large JOIN small
ON large.foo = small.foo
```

or

```sql
SELECT /*+  BROADCASTJOIN(small) */ * 
FROM large JOIN small
ON large.foo = small.foo
```

or

```sql
SELECT /*+ BROADCAST(small) */ * 
FROM large JOIN small
ON larger.foo = small.foo
```

![image-20200622184544245](C:\Users\William-wang2\AppData\Roaming\Typora\typora-user-images\image-20200622184544245.png)

spark.default.parallelism 和spark.sql.shuffle.partitions 区别

```
spark.default.parallelism只有在处理RDD时才会起作用，对Spark SQL的无效。
spark.sql.shuffle.partitions则是对Spark SQL专用的设置
```

统计hive信息：

```
anaylze table glvaluationbeneifitext compute statistics;
```

