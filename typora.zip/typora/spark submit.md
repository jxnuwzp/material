https://www.cnblogs.com/camilla/p/8301750.html

submit job1:

spark-submit --master yarn-cluster \

--jars /usr/hdp/current/hive_warehouse_connector/hive-warehouse-connector-assembly-1.0.0.3.1.5.0-152.jar \

--class erOutput.erOutputMain target/retirementstudio-spark-be-1.0-SNAPSHOT-jar-with-dependencies.jar \

--num-executors 5 \

--executor-memory 8G \

--executor-cores 4



submit job2:

spark-submit --master yarn-cluster \
--jars /usr/hdp/current/hive_warehouse_connector/hive-warehouse-connector-assembly-1.0.0.3.1.5.0-152.jar \
--class SaveHive.MetadataIntoHive retirementstudio-spark-be-1.0-SNAPSHOT-jar-with-dependencies.jar \
--num-executors 5 \
--executor-memory 8G \
--executor-cores 4



submit job2:

spark-submit --master yarn-cluster \
--jars /usr/hdp/current/hive_warehouse_connector/hive-warehouse-connector-assembly-1.0.0.3.1.5.0-152.jar \
--class erOutput.AggValuationLiability.ValuationLiabilityClusterUT retirementstudio-spark-be-1.0-SNAPSHOT-jar-with-dependencies.jar \
--num-executors 5 \
--executor-memory 8G \
--executor-cores 4



copy package into cluster:

scp retirementstudio-spark-be-1.0-SNAPSHOT-jar-with-dependencies.jar erpostengine@10.128.164.22://home/erpostengine/code



kill application:

yarn application -kill application_1567014676729_0955

yarn logs -applicationId application_1567014676729_0610

### search：

hdfs dfs -ls -R hdfs://stu-hdp-large-m0.nmp0f2m1tgaebcb1udgwq1iwng.cx.internal.cloudapp.net:8020



## put data into hdfs:

hdfs dfs -put /mnt/resource/staging/william/retirementstudio-spark-be/src/test/scala/testFiles/AggFVPayoutResult/Ind_FVPayoutResultDimStaging_205201.txt hdfs://stu-hdp-large-m0.nmp0f2m1tgaebcb1udgwq1iwng.cx.internal.cloudapp.net:8020/user/william/metadata



## SCP deliver data to cluster 

scp -r target/retirementstudio-spark-be-1.0-SNAPSHOT-jar-with-dependencies.jar william@40.84.58.136:/mnt/resource/william/code



## code path

git clone https://williamwangzp@bitbucket.org/oliverwymantechssg/retirementstudio-spark-be.git



## hadoop command



https://hadoop.apache.org/docs/current/hadoop-project-dist/hadoop-common/FileSystemShell.html

https://wiki.archlinux.org/index.php/Access_Control_Lists

https://hadoop.apache.org/docs/current/hadoop-project-dist/hadoop-hdfs/HdfsPermissionsGuide.html

https://hadoop.apache.org/docs/current/hadoop-project-dist/hadoop-hdfs/HdfsPermissionsGuide.html