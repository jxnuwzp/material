HBase parallel reading:



https://developer.aliyun.com/article/25777

https://www.programmersought.com/article/75301488692/

https://github.com/apache/phoenix/blob/master/phoenix-core/src/main/java/org/apache/phoenix/schema/PTableImpl.java

