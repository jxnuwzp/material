updatestatebykey

<https://blog.csdn.net/m0_37914799/article/details/84703854>

<https://blog.csdn.net/zhanglh046/article/details/78505124>

<https://www.cnblogs.com/zhangXingSheng/p/6779565.html>

<https://zhou-yuefei.iteye.com/blog/2303007>

<https://github.com/YuvalItzchakov/spark-stateful-example/tree/master/src/main/scala/com/github/yuvalitzchakov/user>

