download:https://maven.apache.org/download.cgi#

mercer@williamlocal:~$ mvn package

Command 'mvn' not found, but can be installed with:

sudo apt install maven

mercer@williamlocal:~$ sudo apt install maven
[sudo] password for mercer: 
E: dpkg was interrupted, you must manually run 'sudo dpkg --configure -a' to correct the problem. 
mercer@williamlocal:~$ cd Downloads/
mercer@williamlocal:~/Downloads$ ls
apache-hive-2.3.2-bin.tar.gz
apache-hive-2.3.3-bin
apache-maven-3.6.1-bin.tar.gz
hadoop
hadoop1
hadoop-2.7.0.tar.gz
hive
ideaIC-2018.3.5.tar.gz
jdk-8u201-linux-x64.tar.gz
kafka
kafka_2.11-2.0.0.tgz
mysql-connector-java_8.0.15-1ubuntu18.10_all.deb
spark-2.3.2-bin-hadoop2.7
spark-2.3.2-bin-hadoop2.7.tgz
spark-2.4.0-bin-hadoop2.7.tgz
zeppelin-0.8.1-bin-all.tgz
zeppelin-0.8.1-bin-all.tgz.part
zookeeper
zookeeper-3.4.13.tar.gz
mercer@williamlocal:~/Downloads$ mv apache-maven-3.6.1-bin.tar.gz
mv: missing destination file operand after 'apache-maven-3.6.1-bin.tar.gz'
Try 'mv --help' for more information.
mercer@williamlocal:~/Downloads$ sudo mv apache-maven-3.6.1-bin.tar.gz /usr/local
mercer@williamlocal:~/Downloads$ cd /usr/local
mercer@williamlocal:/usr/local$ ls
apache-maven-3.6.1-bin.tar.gz  derby  games    lib  sbin  share
bin                            etc    include  man  sbt   src
mercer@williamlocal:/usr/local$ tar txvf apache-maven-3.6.1-bin.tar.gz
tar: You may not specify more than one '-Acdtrux', '--delete' or  '--test-label' option
Try 'tar --help' or 'tar --usage' for more information.
mercer@williamlocal:/usr/local$ tar -txvf apache-maven-3.6.1-bin.tar.gz
tar: You may not specify more than one '-Acdtrux', '--delete' or  '--test-label' option
Try 'tar --help' or 'tar --usage' for more information.
mercer@williamlocal:/usr/local$ sudo tar -txvf apache-maven-3.6.1-bin.tar.gz
tar: You may not specify more than one '-Acdtrux', '--delete' or  '--test-label' option
Try 'tar --help' or 'tar --usage' for more information.
mercer@williamlocal:/usr/local$ sudo tar --txvf apache-maven-3.6.1-bin.tar.gz
tar: unrecognized option '--txvf'
Try 'tar --help' or 'tar --usage' for more information.
mercer@williamlocal:/usr/local$ sudo tar -zxvf apache-maven-3.6.1-bin.tar.gz
apache-maven-3.6.1/README.txt
apache-maven-3.6.1/LICENSE
apache-maven-3.6.1/NOTICE
apache-maven-3.6.1/lib/
apache-maven-3.6.1/lib/slf4j-api.license
apache-maven-3.6.1/lib/checker-compat-qual.license
apache-maven-3.6.1/lib/jsr250-api.license
apache-maven-3.6.1/lib/jcl-over-slf4j.license
apache-maven-3.6.1/lib/org.eclipse.sisu.plexus.license
apache-maven-3.6.1/lib/animal-sniffer-annotations.license
apache-maven-3.6.1/lib/org.eclipse.sisu.inject.license
apache-maven-3.6.1/lib/jansi-native/
apache-maven-3.6.1/lib/jansi-native/freebsd64/
apache-maven-3.6.1/lib/jansi-native/osx/
apache-maven-3.6.1/lib/jansi-native/windows32/
apache-maven-3.6.1/lib/jansi-native/linux32/
apache-maven-3.6.1/lib/jansi-native/freebsd32/
apache-maven-3.6.1/lib/jansi-native/windows64/
apache-maven-3.6.1/lib/jansi-native/linux64/
apache-maven-3.6.1/lib/jansi-native/freebsd64/libjansi.so
apache-maven-3.6.1/lib/jansi-native/osx/libjansi.jnilib
apache-maven-3.6.1/lib/jansi-native/windows32/jansi.dll
apache-maven-3.6.1/lib/jansi-native/linux32/libjansi.so
apache-maven-3.6.1/lib/jansi-native/freebsd32/libjansi.so
apache-maven-3.6.1/lib/jansi-native/windows64/jansi.dll
apache-maven-3.6.1/lib/jansi-native/linux64/libjansi.so
apache-maven-3.6.1/bin/mvn.cmd
apache-maven-3.6.1/bin/m2.conf
apache-maven-3.6.1/bin/mvnDebug.cmd
apache-maven-3.6.1/bin/mvnDebug
apache-maven-3.6.1/bin/mvn
apache-maven-3.6.1/bin/mvnyjp
apache-maven-3.6.1/conf/
apache-maven-3.6.1/conf/logging/
apache-maven-3.6.1/conf/settings.xml
apache-maven-3.6.1/conf/toolchains.xml
apache-maven-3.6.1/conf/logging/simplelogger.properties
apache-maven-3.6.1/lib/ext/
apache-maven-3.6.1/lib/jansi-native/
apache-maven-3.6.1/lib/ext/README.txt
apache-maven-3.6.1/lib/jansi-native/README.txt
apache-maven-3.6.1/boot/plexus-classworlds-2.6.0.jar
apache-maven-3.6.1/lib/maven-embedder-3.6.1.jar
apache-maven-3.6.1/lib/maven-settings-3.6.1.jar
apache-maven-3.6.1/lib/plexus-utils-3.2.0.jar
apache-maven-3.6.1/lib/maven-settings-builder-3.6.1.jar
apache-maven-3.6.1/lib/maven-builder-support-3.6.1.jar
apache-maven-3.6.1/lib/plexus-interpolation-1.25.jar
apache-maven-3.6.1/lib/plexus-component-annotations-1.7.1.jar
apache-maven-3.6.1/lib/plexus-sec-dispatcher-1.4.jar
apache-maven-3.6.1/lib/plexus-cipher-1.7.jar
apache-maven-3.6.1/lib/maven-core-3.6.1.jar
apache-maven-3.6.1/lib/maven-model-3.6.1.jar
apache-maven-3.6.1/lib/maven-repository-metadata-3.6.1.jar
apache-maven-3.6.1/lib/maven-artifact-3.6.1.jar
apache-maven-3.6.1/lib/commons-lang3-3.8.1.jar
apache-maven-3.6.1/lib/maven-plugin-api-3.6.1.jar
apache-maven-3.6.1/lib/org.eclipse.sisu.plexus-0.3.3.jar
apache-maven-3.6.1/lib/cdi-api-1.0.jar
apache-maven-3.6.1/lib/jsr250-api-1.0.jar
apache-maven-3.6.1/lib/javax.inject-1.jar
apache-maven-3.6.1/lib/org.eclipse.sisu.inject-0.3.3.jar
apache-maven-3.6.1/lib/maven-model-builder-3.6.1.jar
apache-maven-3.6.1/lib/maven-resolver-provider-3.6.1.jar
apache-maven-3.6.1/lib/maven-resolver-api-1.3.3.jar
apache-maven-3.6.1/lib/maven-resolver-spi-1.3.3.jar
apache-maven-3.6.1/lib/maven-resolver-util-1.3.3.jar
apache-maven-3.6.1/lib/maven-resolver-impl-1.3.3.jar
apache-maven-3.6.1/lib/slf4j-api-1.7.25.jar
apache-maven-3.6.1/lib/maven-shared-utils-3.2.1.jar
apache-maven-3.6.1/lib/commons-io-2.5.jar
apache-maven-3.6.1/lib/guice-4.2.1-no_aop.jar
apache-maven-3.6.1/lib/aopalliance-1.0.jar
apache-maven-3.6.1/lib/guava-25.1-android.jar
apache-maven-3.6.1/lib/jsr305-3.0.2.jar
apache-maven-3.6.1/lib/checker-compat-qual-2.0.0.jar
apache-maven-3.6.1/lib/error_prone_annotations-2.1.3.jar
apache-maven-3.6.1/lib/j2objc-annotations-1.1.jar
apache-maven-3.6.1/lib/animal-sniffer-annotations-1.14.jar
apache-maven-3.6.1/lib/commons-cli-1.4.jar
apache-maven-3.6.1/lib/maven-compat-3.6.1.jar
apache-maven-3.6.1/lib/wagon-provider-api-3.3.2.jar
apache-maven-3.6.1/lib/wagon-http-3.3.2-shaded.jar
apache-maven-3.6.1/lib/jcl-over-slf4j-1.7.25.jar
apache-maven-3.6.1/lib/wagon-file-3.3.2.jar
apache-maven-3.6.1/lib/maven-resolver-connector-basic-1.3.3.jar
apache-maven-3.6.1/lib/maven-resolver-transport-wagon-1.3.3.jar
apache-maven-3.6.1/lib/maven-slf4j-provider-3.6.1.jar
apache-maven-3.6.1/lib/jansi-1.17.1.jar
mercer@williamlocal:/usr/local$ rm apache-maven-3.6.1-bin.tar.gz
rm: cannot remove 'apache-maven-3.6.1-bin.tar.gz': Permission denied
mercer@williamlocal:/usr/local$ ls
apache-maven-3.6.1             bin    etc    include  man   sbt    src
apache-maven-3.6.1-bin.tar.gz  derby  games  lib      sbin  share
mercer@williamlocal:/usr/local$ sudo rm apache-maven-3.6.1-bin.tar.gz
mercer@williamlocal:/usr/local$ ls
apache-maven-3.6.1  derby  games    lib  sbin  share
bin                 etc    include  man  sbt   src
mercer@williamlocal:/usr/local$ vim ~/.bashrc
mercer@williamlocal:/usr/local$ vim ~/.bashrc
mercer@williamlocal:/usr/local$ source ~/.bashrc
mercer@williamlocal:/usr/local$ mvn -v
Apache Maven 3.6.1 (d66c9c0b3152b2e69ee9bac180bb8fcc8e6af555; 2019-04-04T12:00:29-07:00)
Maven home: /usr/local/apache-maven-3.6.1
Java version: 1.8.0_201, vendor: Oracle Corporation, runtime: /usr/lib/jvm/java-8-oracle/jre
Default locale: en_US, platform encoding: UTF-8
OS name: "linux", version: "4.18.0-17-generic", arch: "amd64", family: "unix"