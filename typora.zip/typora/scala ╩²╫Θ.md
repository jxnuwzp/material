# 定义数组

创建一个数组，格式形如：

```
var z:Array[String] = new Array[String](3)
或
var z = new Array[String](3)
```

### 定长数组

```
object HelloScala {
  def main(args: Array[String]): Unit = {
    //注意下面两种写法的区别！
  //没有new相当于一个定长为1的数组，里面的元素是3。有new相当于初始化一个长度为3的数组，元素值初始均为0。
    val array1 = Array[Int](3)
    val array2 = new Array[Int](3)
    //直接打印定长数组，内容为数组的hashcode值
  println(array)
    //将数组转换成数组缓冲（toBuffer），就可以看到原数组中的内容了
  println(array.toBuffer)
   println(array1.toBuffer)
   println(array2.toBuffer)
   //给数组元素赋值
  array2(0)=1
   println(array2.toBuffer)
  }
}
```

### 变长数组

Array是定长数组，而ArrayBuffer是可变数组

```
import scala.collection.mutable.ArrayBuffer
object HelloScala {
  def main(args: Array[String]): Unit = {
    val arraybuffer = ArrayBuffer[Int]()
    //+=尾部追加元素
    arraybuffer += (1,2,3,4)
    println(arraybuffer)
    //++=追加一个数组
    arraybuffer ++= Array(5,6)
    println(arraybuffer)
    //++=追加一个数组缓冲
    arraybuffer ++= ArrayBuffer(7,8)
    println(arraybuffer)
    //插入元素
    arraybuffer.insert(0,0)
    println(arraybuffer)
    //删除元素，第一个参数是位置，第二个参数是个数，即从第0位开始删除5个元素
    arraybuffer.remove(0,5)
    println(arraybuffer)
  }
}
```

# 数组遍历

类似Java中的For增强 ：i<-arrays表示把arrays数组的元素一个个的赋值给i

```
object HelloScala {
  def main(args: Array[String]): Unit = {
    val arrays = Array(1,2,3)
    for(i <- arrays){
      println(i)
    }
  }
}
```

# 数组转化

数组的转化指的是从一个数组到另一个数组。转化数组有许多方法，比如通过filter方法能过滤出符合条件的数据，map数据是对每一个数据都进行某种指定操作。还可以对数组进行反转操作等。

```
object HelloScala {
  def main(args: Array[String]): Unit = {
    val arrays = Array(1,2,3)
        //需求：筛选出数组中能被2整除的数。并且对它进行加2操作。转化为一个新数组。
 
        //方法一：使用yield转换
    val change_arrays = for(i<-arrays if i%2==0)yield i+2
    println(change_arrays.toBuffer)
 
        //方法二：更高级的写法 使用filter map等函数
    val change_arrays1 = arrays.filter(x=>x%2==0).map(x=>x+2)
    //可以使用这种简写方式：
    //val change_arrays1 = arrays.filter( _%2 == 0).map(_+2)
    println(change_arrays1.toBuffer)
 
    //反转数组
    val ar = arrays.reverse
    println(ar.toBuffer)
 
    //将数组转为字符串
    var ms = arrays.mkString
    println(ms)
  }
}
```

# 数组常用算法

```
object HelloScala {
  def main(args: Array[String]): Unit = {
    val arrays = Array(1, 4, 3,4)
    //计算总和
    println(arrays.sum)
    //满足条件的元素个数
    println(arrays.count(x => x > 2))
    //最大值
    println(arrays.max)
    //take(n)取前面两个元素
    println(arrays.take(2).toBuffer)
    //distinct去除重复元素
    println(arrays.distinct.toBuffer)
    //sorted排序
    println(arrays.sorted.toBuffer)
    //返回指定元素的索引
    println(arrays.indexOf(3))
    //fold函数将一种格式的输入数据转化成另外一种格式返回
    println(arrays.fold(10){(a,b)=>a+b})//10+1+4+3+4=22(10为初始值)
    //交集 并集 
    val arrays1= Array(1,2,3,4)
    println(arrays1.union(arrays).toBuffer)//并集不去重
    println(arrays1.intersect(arrays).toBuffer)//交集去重
  }
}
```

关于数组的更多常用转化方法和算法，强烈建议直接看

和JAVA的二维数组类似，像矩阵与表格就是我们常见的二维数组。

```
object Test {
   def main(args: Array[String]) {
      var myMatrix = ofDim[Int](3,3)
 
      // 创建矩阵
      for (i <- 0 to 2) {
         for ( j <- 0 to 2) {
            myMatrix(i)(j) = j;
         }
      }
 
      // 打印二维阵列
      for (i <- 0 to 2) {
         for ( j <- 0 to 2) {
            print(" " + myMatrix(i)(j));
         }
         println();
      }
 
   }
}
```

### Array

与Java的Array类似，也是长度不可变的数组，此外，由于Scala与Java都是运行在JVM中，双方可以互相调用，因此Scala数组的底层实际上是Java数组。

> 注意：访问数组中元素使用（）而不是Java中的 []

```scala
scala> val a = new Array[String](10)
a: Array[String] = Array(null, null, null, null, null, null, null, null, null, n
ull)
scala> val a = new Array[Boolean](10)
a: Array[Boolean] = Array(false, false, false, false, false, false, false, false
, false, false)
scala> a(0)
res15: Boolean = false
scala> val a = new Array[Int](10)
a: Array[Int] = Array(0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
scala> a(0) = 1
```

 
可以直接使用Array()创建数组，元素类型自动推断（**如果类型不一致则为公共父类型**）

```scala
scala> val a = Array("Hello", "World")
a: Array[String] = Array(Hello, World)
scala> val a = Array("Sparks", 30)
a: Array[Any] = Array(Sparks, 30)

// 常见操作
scala> val a = Array(3,4,1,2,5,3)
a: Array[Int] = Array(3, 4, 1, 2, 5, 3)
scala> val sum = a.sum
sum: Int = 18
scala> val max = a.max
max: Int = 5
scala> scala.util.Sorting.quickSort(a)
scala> a
res35: Array[Int] = Array(1, 2, 3, 3, 4, 5)
scala> a.mkString
res36: String = 123345
scala> a.mkString(",")
res37: String = 1,2,3,3,4,5
scala> a.mkString("<",",",">")
res38: String = <1,2,3,3,4,5>
// Array的toString有些问题
scala> a.toString
res39: String = [I@ffd26d1
scala> b.toString
res40: String = ArrayBuffer(1, 6, 7, 8, 9, 10)
```

 

### ArrayBuffer

类似于Java中的ArrayList长度可变集合类

```scala
scala> import scala.collection.mutable.ArrayBuffer
import scala.collection.mutable.ArrayBuffer
scala> val b = ArrayBuffer[Int]()
b: scala.collection.mutable.ArrayBuffer[Int] = ArrayBuffer()
// 使用+=添加一个或者多个元素，spark源码中大量使用！！！
scala> b += 1
res17: b.type = ArrayBuffer(1)
scala> b += (2,3,4,5)
res18: b.type = ArrayBuffer(1, 2, 3, 4, 5)
// 使用++=添加其他集合中的所有元素
scala> b ++= Array(6, 7, 8, 9, 10)
res19: b.type = ArrayBuffer(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
// trimEnd方法可以从尾部截断指定个数的元素
scala> b.trimEnd(5)
scala> b
res21: scala.collection.mutable.ArrayBuffer[Int] = ArrayBuffer(1, 2, 3, 4, 5)
// 使用insert()函数可以在指定位置插入一个或者多个元素，效率较低
scala> b.insert(5,6)
scala> b.insert(6, 7, 8, 9, 10)
scala> b
res24: scala.collection.mutable.ArrayBuffer[Int] = ArrayBuffer(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
// 使用remove（）函数可以移除指定位置的一个或者多个元素
scala> b.remove(1)
res25: Int = 2
scala> b.remove(1, 3)
scala> b
res27: scala.collection.mutable.ArrayBuffer[Int] = ArrayBuffer(1, 6, 7, 8, 9, 10)
// Array与ArrayBuffer互相转化
scala> b.toArray
res28: Array[Int] = Array(1, 6, 7, 8, 9, 10)
scala> a.toBuffer
res29: scala.collection.mutable.Buffer[Any] = ArrayBuffer(Sparks, 30)
```

 

### 遍历Array和ArrayBuffer

1. 使用until是RichInt提供的函数
   for (i <- 0 until b.length)
   print(b(i))
2. 跳跃遍历，步进长度
   for (i <- 0 until (b.length, 2))
   print(b(i))
3. 从尾部遍历
   for (i <- (0 until b.length).reverse)
   println(b(i))
4. 使用“增强for循环”遍历
   for (e <- b)
   println(e)

 

### 数组操作之数组转换

1.使用yield

```
scala> val a = Array(1,2,3,4,5)
a: Array[Int] = Array(1, 2, 3, 4, 5)

scala> val a2 = for(ele <- a) yield ele*ele
a2: Array[Int] = Array(1, 4, 9, 16, 25)

scala> val a = ArrayBuffer(1,2,3,4,5)
a: scala.collection.mutable.ArrayBuffer[Int] = ArrayBuffer(1, 2, 3, 4, 5)

scala> val a2 = for(ele <- a) yield ele*ele
a2: scala.collection.mutable.ArrayBuffer[Int] = ArrayBuffer(1, 4, 9, 16, 25)
```

2.使用函数式编程
_ 表示通配符

- a.filter(_ % 2 == 0).map(2 * _) （推荐方式）
- a.filter{ _ % 2 == 0} map {2 * _}

 

### 实战：移除第一个负数之后的所有负数

```scala
// 构建数组
scala> val a = ArrayBuffer[Int]()
a: scala.collection.mutable.ArrayBuffer[Int] = ArrayBuffer()
scala> a += (1,2,3,4,5,-1,-3,-5,-9)
res45: a.type = ArrayBuffer(1, 2, 3, 4, 5, -1, -3, -5, -9)

// 发现第一个负数之后的负数，就进行移除，性能较差，多次移动数组
var foundFirstNegative = false
var index = 0
while(index < a.length) {
  if (a(index) >= 0) {
    index += 1
  }
  else {
    if (!foundFirstNegative) {foundFirstNegative=true; index += 1}
    else { a.remove(index)}
  }
}

//检索出所有需要元素的下标，然后将所有需要的元素左移至数组左侧，删除右侧不需要的元素。
//改良版，性能较高
var foundFirstNegative = false
val vaildIndex = for (i <- 0 until a.length if (!foundFirstNegative || a(i) >= 0)) yield {
  if (a(i) < 0) foundFirstNegative = true
  i
}
for(i <- 0 until vaildIndex.length) {a(i) = a(vaildIndex(i))}
a.trimEnd(a.length - vaildIndex.length)
```



算法题：https://www.nowcoder.com/ta/job-code-high-rd